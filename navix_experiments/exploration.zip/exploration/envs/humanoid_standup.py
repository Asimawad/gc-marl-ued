from brax import actuator
from brax import base
from brax.envs.base import PipelineEnv, State
from brax.io import mjcf
import jax
from jax import numpy as jp
import mujoco
import os

# This is based on original Humanoid environment from Brax
# https://github.com/google/brax/blob/main/brax/envs/humanoid.py

# This is chosen to be very close to the z coordinate of the humanoid torso, when it is standing straight
TARGET_Z_COORD = 1.25

class HumanoidStandup(PipelineEnv):

    def __init__(
            self, 
            backend='generalized', 
            reset_noise_scale=0.0,
            exclude_current_positions_from_observation=True,
            **kwargs
        ):

        path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'assets', "humanoid_standup.xml")
        sys = mjcf.load(path)

        n_frames = 5

        if backend in ['spring', 'positional']:
            sys = sys.tree_replace({'opt.timestep': 0.0015})
            # sys = sys.replace(dt=0.0015)
            n_frames = 10
            sys = sys.replace(
                actuator=sys.actuator.replace(
                    gear=jp.array([350.0, 350.0, 350.0, 350.0, 350.0, 350.0,
                        350.0, 350.0, 350.0, 350.0, 350.0, 100.0, 100.0,
                        100.0, 100.0, 100.0, 100.0])))  # pyformat: disable

        kwargs['n_frames'] = kwargs.get('n_frames', n_frames)

        super().__init__(sys=sys, backend=backend, **kwargs)
        
        self._reset_noise_scale = reset_noise_scale
        self._exclude_current_positions_from_observation = (
            exclude_current_positions_from_observation
        )
        
    def reset(self, rng: jax.Array) -> State:
        """Resets the environment to an initial state."""
        rng, rng1, rng2 = jax.random.split(rng, 3)

        low, hi = -self._reset_noise_scale, self._reset_noise_scale
        qpos = self.sys.init_q + jax.random.uniform(
            rng1, (self.sys.q_size(),), minval=-0.01, maxval=0.01
        )
        qvel = jax.random.uniform(
            rng2, (self.sys.qd_size(),), minval=low, maxval=hi
        )

        pipeline_state = self.pipeline_init(qpos, qvel)
        obs = self._get_obs(pipeline_state, jp.zeros(self.sys.act_size()))
        reward, done, zero = jp.zeros(3)
        metrics = {
            'reward_linup': zero,
            'reward_quadctrl': zero,
            'distance_from_origin': zero,
            "dist":zero,
            "success": zero,
            "success_easy": zero,
        }
    
        info = {"seed":0}
        state = State(pipeline_state, obs, reward, done, metrics)
        state.info.update(info)

        return state
    
    def step(self, state: State, action: jax.Array) -> State:
        """Runs one timestep of the environment's dynamics."""

        if "steps" in state.info.keys():
            seed = state.info["seed"] + jp.where(state.info["steps"], 0, 1)
        else:
            seed = state.info["seed"]
        info = {"seed": seed}

        # Scale action from [-1,1] to actuator limits
        action_min = self.sys.actuator.ctrl_range[:, 0]
        action_max = self.sys.actuator.ctrl_range[:, 1]
        action = (action + 1) * (action_max - action_min) * 0.5 + action_min

        pipeline_state = self.pipeline_step(state.pipeline_state, action)

        pos_after = pipeline_state.x.pos[0, 2]  # z coordinate of torso
        uph_cost = (pos_after - 0) / self.dt
        quad_ctrl_cost = 0.01 * jp.sum(jp.square(action))
        # quad_impact_cost is not computed here

        obs = self._get_obs(pipeline_state, action)
        distance_to_target = jp.linalg.norm(obs[0 if self._exclude_current_positions_from_observation else 2] - obs[-1])
        reward = uph_cost + 1 - quad_ctrl_cost
        success = jp.array(distance_to_target < 0.2, dtype=float)
        success_easy = jp.array(distance_to_target < 0.5, dtype=float)

        state.metrics.update(
            reward_linup=uph_cost, 
            reward_quadctrl=-quad_ctrl_cost,
            distance_from_origin=jp.linalg.norm(pipeline_state.x.pos[0, :3]),
            dist=distance_to_target,
            success=success,
            success_easy=success_easy,
        )

        state.info.update(info)
        return state.replace(
            pipeline_state=pipeline_state, obs=obs, reward=reward
        )

    def _get_obs(
        self, pipeline_state: base.State, action: jax.Array
    ) -> jax.Array:
        """Observes humanoid body position, velocities, and angles."""
        if self._exclude_current_positions_from_observation:
            position = pipeline_state.q[2:]
            velocity = pipeline_state.qd

        com, inertia, mass_sum, x_i = self._com(pipeline_state)
        cinr = x_i.replace(pos=x_i.pos - com).vmap().do(inertia)
        com_inertia = jp.hstack(
            [cinr.i.reshape((cinr.i.shape[0], -1)), inertia.mass[:, None]]
        )

        xd_i = (
            base.Transform.create(pos=x_i.pos - pipeline_state.x.pos)
            .vmap()
            .do(pipeline_state.xd)
        )
        com_vel = inertia.mass[:, None] * xd_i.vel / mass_sum
        com_ang = xd_i.ang
        com_velocity = jp.hstack([com_vel, com_ang])

        qfrc_actuator = actuator.to_tau(
        self.sys, action, pipeline_state.q, pipeline_state.qd)

        # external_contact_forces are excluded
        return jp.concatenate([
            position,
            velocity,
            com_inertia.ravel(),
            com_velocity.ravel(),
            qfrc_actuator,
            jp.array([TARGET_Z_COORD])
        ])

    def _com(self, pipeline_state: base.State) -> jax.Array:
        inertia = self.sys.link.inertia
        if self.backend in ['spring', 'positional']:
            inertia = inertia.replace(
                i=jax.vmap(jp.diag)(
                    jax.vmap(jp.diagonal)(inertia.i)
                    ** (1 - self.sys.spring_inertia_scale)
                ),
                mass=inertia.mass ** (1 - self.sys.spring_mass_scale),
            )

        mass_sum = jp.sum(inertia.mass)
        x_i = pipeline_state.x.vmap().do(inertia.transform)
        com = (
         jp.sum(jax.vmap(jp.multiply)(inertia.mass, x_i.pos), axis=0) / mass_sum
        )

        return com, inertia, mass_sum, x_i  # pytype: disable=bad-return-type  # jax-ndarray


def _random_target(self, rng: jax.Array):
    rng, rng1 = jax.random.split(rng, 3)
    target_z =  jax.random.uniform(rng1, minval=1, maxval=2) 
    return rng, jp.array([target_z])