import jax
import navix as nx
import jax.numpy as jnp

from jax import Array
from flax import struct
from typing import Union

from envs.nx_envs import Environment, Timestep

from navix.states import State
from navix import register_env
from navix.components import EMPTY_POCKET_ID, Directional, HasColour, Openable
from navix.rendering.cache import RenderingCache
from navix.rendering.registry import PALETTE
from navix.entities import Player, Wall, EntityIds, Door, Key
from navix.grid import random_positions, random_directions, room
from navix.spaces import Discrete
from navix.grid import mask_by_coordinates, room, random_positions, random_directions

door_key_88_goal_coords = jnp.array([6,6], dtype=jnp.int32)

door_key_goal_coords = jnp.array([14,14], dtype=jnp.int32)

class gcrl_DoorKey(Environment):
    random_start: bool = struct.field(pytree_node=False, default=False)

    def _reset(self, key: Array, cache: Union[RenderingCache, None] = None) -> Timestep:
        # check minimum height and width
        assert (
            self.height > 3
        ), f"Room height must be greater than 3, got {self.height} instead"
        assert (
            self.width > 4
        ), f"Room width must be greater than 5, got {self.width} instead"

        key, k1, k2, k3, k4 = jax.random.split(key, 5)

        grid = room(height=self.height, width=self.width)

        # # door positions
        # # col can be between 1 and height - 2
        # door_col = jax.random.randint(k4, (), 2, self.width - 2)  # col
        # # row can be between 1 and height - 2
        # door_row = jax.random.randint(k3, (), 1, self.height - 1)  # row

        # used fixed door positions
        door_col = 8
        door_row = 8

        door_pos = jnp.asarray((door_row, door_col))
        doors = Door.create(
            position=door_pos,
            requires=jnp.asarray(3),
            open=jnp.asarray(False),
            colour=PALETTE.YELLOW,
        )

        # wall positions
        wall_rows = jnp.arange(1, self.height - 1)
        wall_cols = jnp.asarray([door_col] * (self.height - 2))
        wall_pos = jnp.stack((wall_rows, wall_cols), axis=1)
        # remove wall where the door is
        wall_pos = jnp.delete(
            wall_pos, door_row - 1, axis=0, assume_unique_indices=True
        )
        walls = Wall.create(position=wall_pos)

        # get rooms
        first_room_mask = mask_by_coordinates(
            grid, (jnp.asarray(self.height), door_col), jnp.less
        )
        first_room = jnp.where(first_room_mask, grid, -1)  # put walls where not mask
        second_room_mask = mask_by_coordinates(
            grid, (jnp.asarray(0), door_col), jnp.greater
        )
        second_room = jnp.where(second_room_mask, grid, -1)  # put walls where not mask

        # set player and goal pos
        if self.random_start:
            player_pos = random_positions(k1, first_room)
            player_dir = random_directions(k2)
            # goal_pos = random_positions(k2, second_room)
        else:
            player_pos = jnp.asarray([1, 1])
            player_dir = jnp.asarray(0)
            # goal_pos = jnp.asarray([self.height - 2, self.width - 2])

        # spawn goal and player
        player = Player.create(
            position=player_pos, direction=player_dir, pocket=EMPTY_POCKET_ID
        )
        # goals = Goal.create(position=goal_pos, probability=jnp.asarray(1.0))

        # spawn key
        # key_pos = random_positions(k2, first_room, exclude=player_pos)
        key_pos = jnp.asarray([10, 1])
        keys = Key.create(position=key_pos, id=jnp.asarray(3), colour=PALETTE.YELLOW)

        # remove the wall beneath the door
        grid = grid.at[tuple(door_pos)].set(0)

        entities = {
            "player": player[None],
            "key": keys[None],
            "door": doors[None],
            # "goal": goals[None],
            "wall": walls,
        }

        state = State(
            key=key,
            grid=grid,
            cache=cache or RenderingCache.init(grid),
            entities=entities,
        )
        return Timestep(
            t=jnp.asarray(0, dtype=jnp.int32),
            observation=self.observation_fn(state),
            action=jnp.asarray(-1, dtype=jnp.int32),
            reward=jnp.asarray(0.0, dtype=jnp.float32),
            step_type=jnp.asarray(0, dtype=jnp.int32),
            state=state,
        )

def on_goal_reached_88(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array([6,6], dtype=jnp.int32)), dtype=jnp.float32)

def on_goal_reached(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array([14,14], dtype=jnp.int32)), dtype=jnp.float32)
    
def free(prev_state: State, action: Array, state: State) -> Array:
    """never terminate.

    Args:
        prev_state (State): The previous state of the game.
        action (Array): The action taken by the player.
        state (State): The current state of the game.

    Returns:
        Array: A boolean array indicating false everywhere."""
    return jnp.zeros_like(nx.events.on_ball_hit(state), dtype=jnp.bool_)

def symbolic(state: State) -> Array:
    """Fully observable grid with a symbolic state representation as originally \
    proposed in the MiniGrid environment.
    The symbol is a triple of (OBJECT_TAG, COLOUR_IDX, OPEN/CLOSED/LOCKED). The
    last layer might also contain the direction of the entity, for example, the
    direction of the agent.
    
    Args:
        state (State): The current state of the game.
        
    Returns:
        Array: A grid of integers, where each integer represents an entity, \
        represented as an array of shape `u8[H, W, 3]`, where `H` and `W` are the height \
        and width of the grid."""
    # initialise as all floors
    H, W = state.grid.shape
    obs = jnp.zeros((H, W, 3), dtype=jnp.uint8)
    wall_symbol = jnp.array([EntityIds.WALL, 5, 0], dtype=jnp.uint8)
    floor_symbol = jnp.array([EntityIds.FLOOR, 0, 0], dtype=jnp.uint8)
    obs = jnp.where(state.grid[..., None] == -1, wall_symbol, floor_symbol)

    # place entities
    for entity_class in state.entities:
        entity = state.entities[entity_class]
        tag = entity.tag
        # colour layer
        if isinstance(entity, HasColour):
            colour = entity.colour
        else:
            colour = jnp.zeros(entity.shape)
        # state layer
        if isinstance(entity, Openable):
            entity_state = (1 - entity.open)
            # entity_state = entity.open + (entity.requires != jnp.zeros(entity.shape))
        elif isinstance(entity, Directional):
            entity_state = entity.direction
        else:
            entity_state = jnp.zeros(entity.shape)
        entity_symbol = jnp.stack([tag, colour, entity_state], axis=-1, dtype=jnp.uint8)
        obs = obs.at[tuple(entity.position.T)].set(entity_symbol)
    
    # print("obs.shape", obs.shape)
    return jnp.expand_dims(obs[:,:,0]*0.1 + obs[:,:,2]*0.01, axis=-1)

register_env(
    "gcrl_door_key-8x8",
    lambda *args, **kwargs: gcrl_DoorKey.create(
        height=8,
        width=8,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(8, 8, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached_88),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)

register_env(
    "gcrl_door_key",
    lambda *args, **kwargs: gcrl_DoorKey.create(
        height=16,
        width=16,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(16, 16, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)