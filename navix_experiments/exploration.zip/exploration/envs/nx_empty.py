import navix as nx
import jax
import jax.numpy as jnp

from jax import Array
from flax import struct
from typing import Union

from envs.nx_envs import Environment, Timestep

from navix import register_env
from navix.states import State
from navix.components import EMPTY_POCKET_ID, DISCARD_PILE_IDX, Directional, HasColour, Openable
from navix.rendering.cache import RenderingCache
from navix.spaces import Space, Discrete, Continuous
from navix.entities import Entities, Goal, Player, EntityIds
from navix.grid import random_positions, random_directions, room

empty_goal_coords = jnp.array([14,14], dtype=jnp.int32)

def free(prev_state: State, action: Array, state: State) -> Array:
    """never terminate.

    Args:
        prev_state (State): The previous state of the game.
        action (Array): The action taken by the player.
        state (State): The current state of the game.

    Returns:
        Array: A boolean array indicating false everywhere."""
    return jnp.zeros_like(nx.events.on_ball_hit(state), dtype=jnp.bool_)
    
class gcrl_empty(Environment):
    random_start: bool = struct.field(pytree_node=False, default=False)

    def _reset(self, key: Array, cache: Union[RenderingCache, None] = None) -> Timestep:
        key, k1, k2 = jax.random.split(key, 3)

        # map
        grid = room(height=self.height, width=self.width)

        # goal and player
        if self.random_start:
            raise NotImplementedError
        else:
            player_pos = jnp.asarray([1, 1])
            direction = jnp.asarray(0)
            
        player = Player.create(
            position=player_pos,
            direction=direction,
            pocket=EMPTY_POCKET_ID,
        )

        entities = {
            Entities.PLAYER: player[None],
        }

        # systems
        state = State(
            key=key,
            grid=grid,
            cache=cache or RenderingCache.init(grid),
            entities=entities,
        )
        
        
        return Timestep(
            t=jnp.asarray(0, dtype=jnp.int32),
            observation=self.observation_fn(state),
            action=jnp.asarray(0, dtype=jnp.int32),
            reward=jnp.asarray(0.0, dtype=jnp.float32),
            step_type=jnp.asarray(0, dtype=jnp.int32),
            state=state,
        )

def on_goal_reached(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array([14,14], dtype=jnp.int32)), dtype=jnp.float32)


def symbolic(state: State) -> Array:
    """Fully observable grid with a symbolic state representation as originally \
    proposed in the MiniGrid environment.
    The symbol is a triple of (OBJECT_TAG, COLOUR_IDX, OPEN/CLOSED/LOCKED). The
    last layer might also contain the direction of the entity, for example, the
    direction of the agent.
    
    Args:
        state (State): The current state of the game.
        
    Returns:
        Array: A grid of integers, where each integer represents an entity, \
        represented as an array of shape `u8[H, W, 3]`, where `H` and `W` are the height \
        and width of the grid."""
    # initialise as all floors
    H, W = state.grid.shape
    obs = jnp.zeros((H, W, 3), dtype=jnp.uint8)
    wall_symbol = jnp.array([EntityIds.WALL, 5, 0], dtype=jnp.uint8)
    floor_symbol = jnp.array([EntityIds.FLOOR, 0, 0], dtype=jnp.uint8)
    obs = jnp.where(state.grid[..., None] == -1, wall_symbol, floor_symbol)

    # place entities
    for entity_class in state.entities:
        entity = state.entities[entity_class]
        tag = entity.tag
        # colour layer
        if isinstance(entity, HasColour):
            colour = entity.colour
        else:
            colour = jnp.zeros(entity.shape)
        # state layer
        if isinstance(entity, Openable):
            entity_state = entity.open + (entity.requires != jnp.zeros(entity.shape))
        elif isinstance(entity, Directional):
            entity_state = entity.direction
        else:
            entity_state = jnp.zeros(entity.shape)
        entity_symbol = jnp.stack([tag, colour, entity_state], axis=-1, dtype=jnp.uint8)
        obs = obs.at[tuple(entity.position.T)].set(entity_symbol)
    
    return jnp.expand_dims(obs[:,:,0]*0.1 + obs[:,:,2]*0.01, axis=-1)

register_env(
    "gcrl_empty",
    lambda *args, **kwargs: gcrl_empty.create(
    height=16,
    width=16,
    random_start=False,
    observation_fn=kwargs.pop("observation_fn", symbolic),
    observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(16, 16, 1),
                dtype=jnp.float32,
            )),
    reward_fn=kwargs.pop("reward_fn", on_goal_reached),
    termination_fn=kwargs.pop("termination_fn", free),
    action_set = nx.actions.DEFAULT_ACTION_SET[:3],
    *args,
    **kwargs,
    )
)