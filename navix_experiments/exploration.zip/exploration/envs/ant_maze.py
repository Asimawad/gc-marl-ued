import os
import jax
import mujoco # MuJoCo Python bindings (used here for solver enums and settings, not for full simulation)
import xml.etree.ElementTree as ET # Built-in XML parser for reading and modifying MJCF (MuJoCo XML) files


from brax import base # Brax core: defines the System model and low‑level pipeline functions (init/step)
from brax import math # Brax math helpers: stable, JAX‑friendly operations like safe_norm
from flax import struct # Flax utility for creating immutable, JAX‑compatible dataclasses (PyTree nodes)

# MJCF stands for MuJoCo XML model format—it’s the standard way to describe a physical simulation in MuJoCo using plain XML
from brax.io import mjcf # MJCF loader: parses MuJoCo XML into a Brax System object
from jax import numpy as jnp # JAX's NumPy implementation
from typing import Tuple, Dict # generic types from Python’s typing module used purely for type annotations

# Brax environment base classes:
        # - PipelineEnv: wraps a System into a gym‑style reset/step loop
        # - State      : holds the sim’s dynamic state, observations, rewards, and metadata
from brax.envs.base import PipelineEnv, State

# a decorator that creates a class which can be passed to functional transformations.
# 1) becomes a PyTree node. 2) becomes immutable. 3) gets an auto-generated __init__ matching annotated fields
# dataclasses have an auto-generated __init__ where the arguments of the constructor and the attributes of the created instance match 1:1
@struct.dataclass
class EvalGoals:
	eval_goals: Dict[str, jax.Array]

# This is based on original Ant environment from Brax
# https://github.com/google/brax/blob/main/brax/envs/ant.py
# Maze creation dapted from: https://github.com/Farama-Foundation/D4RL/blob/master/d4rl/locomotion/maze_env.py

RESET = R = 'r'
GOAL = G = 'g'

U_MAZE = [[1, 1, 1, 1, 1],
          [1, R, G, G, 1],
          [1, 1, 1, G, 1],
          [1, G, G, G, 1],
          [1, 1, 1, 1, 1]]

U_MAZE_EASY_EVAL = [[1, 1, 1, 1, 1],
                    [1, R, G, G, 1],
                    [1, 1, 1, G, 1],
                    [1, G, G, G, 1],
                    [1, 1, 1, 1, 1]]

U_MAZE_HARD_EVAL = [[1, 1, 1, 1, 1],
                    [1, R, 0, 0, 1],
                    [1, 1, 1, 0, 1],
                    [1, G, 0, 0, 1],
                    [1, 1, 1, 1, 1]]

BIG_MAZE = [[1, 1, 1, 1, 1, 1, 1, 1],
            [1, R, G, 1, 1, G, G, 1],
            [1, G, G, 1, G, G, G, 1],
            [1, 1, G, G, G, 1, 1, 1],
            [1, G, G, 1, G, G, G, 1],
            [1, G, 1, G, G, 1, G, 1],
            [1, G, G, G, 1, G, G, 1],
            [1, 1, 1, 1, 1, 1, 1, 1]]

BIG_MAZE_EASY_EVAL = [[1, 1, 1, 1, 1, 1, 1, 1],
                    [1, R, G, 1, 1, G, G, 1],
                    [1, G, G, 1, G, G, G, 1],
                    [1, 1, G, G, G, 1, 1, 1],
                    [1, G, G, 1, G, G, G, 1],
                    [1, G, 1, G, G, 1, G, 1],
                    [1, G, G, G, 1, G, G, 1],
                    [1, 1, 1, 1, 1, 1, 1, 1]]

BIG_MAZE_HARD_EVAL = [[1, 1, 1, 1, 1, 1, 1, 1],
                    [1, R, 0, 1, 1, G, G, 1],
                    [1, 0, 0, 1, 0, 0, G, 1],
                    [1, 1, 0, 0, 0, 1, 1, 1],
                    [1, 0, 0, 1, 0, 0, 0, 1],
                    [1, 0, 1, 0, 0, 1, 0, 1],
                    [1, 0, 0, G, 1, G, G, 1],
                    [1, 1, 1, 1, 1, 1, 1, 1]]

HARDEST_MAZE = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                [1, R, G, G, G, 1, G, G, G, G, G, 1],
                [1, G, 1, 1, G, 1, G, 1, G, 1, G, 1],
                [1, G, G, G, G, G, G, 1, G, G, G, 1],
                [1, G, 1, 1, 1, 1, G, 1, 1, 1, G, 1],
                [1, G, G, 1, G, 1, G, G, G, G, G, 1],
                [1, 1, G, 1, G, 1, G, 1, G, 1, 1, 1],
                [1, G, G, 1, G, G, G, 1, G, G, G, 1],
                [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

HARDEST_MAZE_EASY_EVAL =   [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                            [1, R, G, G, G, 1, G, G, G, G, G, 1],
                            [1, G, 1, 1, G, 1, G, 1, G, 1, G, 1],
                            [1, G, G, G, G, G, G, 1, G, G, G, 1],
                            [1, G, 1, 1, 1, 1, G, 1, 1, 1, G, 1],
                            [1, G, G, 1, G, 1, G, G, G, G, G, 1],
                            [1, 1, G, 1, G, 1, G, 1, G, 1, 1, 1],
                            [1, G, G, 1, G, G, G, 1, G, G, G, 1],
                            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

HARDEST_MAZE_HARD_EVAL =     [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                                [1, R, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
                                [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                                [1, 0, 0, 0, 0, 0, 0, 1, G, 0, 0, 1],
                                [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
                                [1, 0, 0, 1, G, 1, 0, 0, 0, 0, 0, 1],
                                [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
                                [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, G, 1],
                                [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

MAZE_HEIGHT = 0.5

def find_robot(structure, size_scaling):
    """
    Scan a 2D maze layout to locate the robot's start cell and convert its grid index
    into continuous world‑space coordinates.

    Args:
        structure (List[List[Union[int, str]]]):
            A 2D list representing the maze.
        size_scaling (float):
            The factor by which each grid cell is scaled in the simulator’s world
            (e.g. if size_scaling=4.0, grid step of 1 ⇒ 4.0 world units).

    Returns:
        Tuple[float, float]:
            The (x, y) world coordinates of the robot’s start position.
    """
    for i in range(len(structure)):
        for j in range(len(structure[0])):
            if structure[i][j] == RESET:
                return i * size_scaling, j * size_scaling

# Similar to the previous funciton. The difference is it returns a list of tuples.            
def find_goals(structure, size_scaling):
    goals = []
    for i in range(len(structure)):
        for j in range(len(structure[0])):
            if structure[i][j] == GOAL:
                goals.append([i * size_scaling, j * size_scaling])

    return jnp.array(goals)


# Create a xml with maze and a list of possible goal positions
def make_maze(maze_layout_name, maze_size_scaling):
    if maze_layout_name == "u_maze":
        maze_layout = U_MAZE
        maze_eval_layouts = {'easy': U_MAZE_EASY_EVAL, 'hard': U_MAZE_HARD_EVAL}
    # sg: single goal from "single goal is all you need" paper
    elif maze_layout_name == "u_maze_sg": # QUESTION: What does this layout represent? Why it has the same layout as evaluation?
        maze_layout = U_MAZE_HARD_EVAL
        maze_eval_layouts = {'easy': U_MAZE_EASY_EVAL, 'hard': U_MAZE_HARD_EVAL}
    elif maze_layout_name == "big_maze":
        maze_layout = BIG_MAZE
        maze_eval_layouts = {'easy': BIG_MAZE_EASY_EVAL, 'hard': BIG_MAZE_HARD_EVAL}
    elif maze_layout_name == "big_maze_sg":
        maze_layout = BIG_MAZE_HARD_EVAL
        maze_eval_layouts = {'easy': BIG_MAZE_EASY_EVAL, 'hard': BIG_MAZE_HARD_EVAL}
    elif maze_layout_name == "hardest_maze":
        maze_layout = HARDEST_MAZE
        maze_eval_layouts = {'easy': HARDEST_MAZE_EASY_EVAL, 'hard': HARDEST_MAZE_HARD_EVAL}
    elif maze_layout_name == "hardest_maze_sg":
        maze_layout = HARDEST_MAZE_HARD_EVAL
        maze_eval_layouts = {'easy': HARDEST_MAZE_EASY_EVAL, 'hard': HARDEST_MAZE_HARD_EVAL}
    else:
        raise ValueError(f"Unknown maze layout: {maze_layout_name}")
    
    # __file__ is the path to the current file.
    # os.path.realpath(path) returns the “ultimate” absolute path after chasing (resolving) all symlinks.
    # os.path.dirname() strips off the filename, leaving just the directory path.
    xml_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'assets', "ant_maze.xml")

    robot_x, robot_y = find_robot(maze_layout, maze_size_scaling)
    possible_goals = find_goals(maze_layout, maze_size_scaling)

    eval_possible_goals = {}
    for key, value in maze_eval_layouts.items():
        eval_possible_goals[key] = find_goals(value, maze_size_scaling)

    eval_possible_goals = EvalGoals(eval_goals=eval_possible_goals)

    # We start from a plain‑vanilla Ant MJCF file (with no maze walls), so we need to load that base XML before we can inject our maze geometry.
    # Load the MJCF into an ElementTree and locate the <worldbody> node where static geometry belongs.
    # “static geometry” simply means any collision or visual shape that sits fixed in the world and never moves or gets attached to a moving body (like the Ant).
    tree = ET.parse(xml_path)
    
    # Find the <worldbody> element, which is where static geometry belongs
    worldbody = tree.find(".//worldbody")

    # inject wall geoms
    for i in range(len(maze_layout)):
        for j in range(len(maze_layout[0])):
            struct = maze_layout[i][j]
            if struct == 1:
                ET.SubElement(
                    worldbody, "geom",
                    name="block_%d_%d" % (i, j),
                    pos="%f %f %f" % (i * maze_size_scaling,
                                    j * maze_size_scaling,
                                    MAZE_HEIGHT / 2 * maze_size_scaling),
                    size="%f %f %f" % (0.5 * maze_size_scaling,
                                        0.5 * maze_size_scaling,
                                        MAZE_HEIGHT / 2 * maze_size_scaling),
                    type="box",
                    material="",
                    contype="1",
                    conaffinity="1",
                    rgba="0.7 0.5 0.3 1.0",
                )

    # Computes the dimensiosn of the maze (distances between centers of outermost walls)
    length = (len(maze_layout) - 1) * maze_size_scaling
    width = (len(maze_layout[0]) - 1) * maze_size_scaling

    # The following three lines set the initial position of the ant.
    # locate the element with the name: init_qpos which describes the initial generalized coordinates of the ant.
    # init_qpos drives the very first state when the environment resets.
    # QUESTION: Why don't we just change the body pos element instead?
    torso = tree.find(".//numeric[@name='init_qpos']")
    data = torso.get("data")
    torso.set("data", f"{robot_x} {robot_y} " + data) 

    # Extract the root Element from the ElementTree
    tree = tree.getroot()
    
    # Serialize that Element (and its whole subtree) into raw XML bytes
    xml_string = ET.tostring(tree)
    
    return xml_string, possible_goals, eval_possible_goals, (int(length), int(width))

def random_target_fn(possible_goals, rng: jax.Array) -> Tuple[jax.Array, jax.Array]:
    """
    Returns a random target location chosen from possibilities specified in the maze layout.

    Args:
        possible_goals: 1-D or 2-D sequence of goal coordinates (e.g. an array of shape (N, 2))
        rng: a JAX PRNG key (an array of shape (2,), dtype=uint32)

    Returns:
        A tuple (new_rng, target), where
          new_rng is the (unchanged) PRNG key,
          target is a 1-D jax.Array of length D (e.g. [x, y]).
    """
    
    # jax.random.randint(key, shape, minval, maxval) draws integers uniformly from [minval, maxval).
    idx = jax.random.randint(rng, (1,), 0, len(possible_goals))
    
    # idx ia a jax array, so possible_goals[idx] returns a 2D array. Indexing with zero squeezes the additional dimension.
    return rng, jnp.array(possible_goals[idx])[0]


# AntMaze inherits from Brax’s PipelineEnv, which provides the core
# JAX‑friendly, multi‑backend simulation loop (reset/step),
# automatic frame‑skipping, and gym‑style API on top of a MuJoCo/Brax System.
class AntMaze(PipelineEnv):
    def __init__(
        self,
        ctrl_cost_weight=0.5,
        use_contact_forces=False, # Not implemented here
        contact_cost_weight=5e-4,
        healthy_reward=1.0,
        terminate_when_unhealthy=True,
        healthy_z_range=(0.2, 1.0),
        contact_force_range=(-1.0, 1.0),
        reset_noise_scale=0.1,
        exclude_current_positions_from_observation=False,
        full_goal_space=False,
        
        # A backend in Brax selects which physics pipeline you use to simulate rigid‑body dynamics.
        # So by passing backend="spring" (or "generalized", "positional", or "mjx"), you pick one of four distinct solvers
        # In a physics simulator, a solver is the piece of code that takes your equations of motion plus any constraints (contacts, joint limits, springs, etc.) and actually computes the next state of the system.
        backend="generalized", 
        maze_layout_name="u_maze",
        maze_size_scaling=4.0,
        **kwargs,
    ):
        xml_string, possible_goals, eval_possible_goals, (self.x_len, self.y_len) = make_maze(maze_layout_name, maze_size_scaling)
        sys = mjcf.loads(xml_string) # Parses the XML into a Brax System object, capturing bodies, joints, actuators, and collision geometry.
        self.possible_goals = possible_goals
        self.eval_possible_goals = eval_possible_goals

        # Set default number of physics sub-steps (integration steps) per environment step
        n_frames = 5

        # If using the spring‐ or positional‐based solver, we need smaller time steps for stability
        if backend in ["spring", "positional"]:
            
            # Reduce the integrator timestep by half to better handle stiff spring/damper contacts
            sys = sys.tree_replace({"opt.timestep": 0.005})
            
            # Double the number of sub-steps so that total simulated time per step remains the same
            n_frames = 10

        # If using the MuJoCo‐via‐XLA backend, override its solver settings for Newton‐based contact resolution
        if backend == "mjx":
            sys = sys.tree_replace(
                {
                    # Switch to the full Newton solver
                    "opt.solver": mujoco.mjtSolver.mjSOL_NEWTON,
                    
                    # Disable MuJoCo’s built‐in Euler damping
                    "opt.disableflags": mujoco.mjtDisableBit.mjDSBL_EULERDAMP,
                    
                    # Control how many solver iterations and line-search iterations MuJoCo runs
                    "opt.iterations": 1,
                    "opt.ls_iterations": 4,
                }
            )

        # For the positional backend, joints use a spring‐damper model and may need stronger actuators
        if backend == "positional":
            # TODO: does the same actuator strength work as in spring
            sys = sys.replace(
                actuator=sys.actuator.replace(
                    # Increase all gear ratios by 200× so the ant’s legs are stiff/powerful enough
                    gear=200 * jnp.ones_like(sys.actuator.gear)
                )
            )

        # Injects your chosen n_frames into the remaining kwargs.
        kwargs["n_frames"] = kwargs.get("n_frames", n_frames)

        # Calls PipelineEnv.__init__, which under the hood compiles the simulation pipelines and wires up reset/step protocols.
        super().__init__(sys=sys, backend=backend, **kwargs)

        self._ctrl_cost_weight = ctrl_cost_weight
        self._use_contact_forces = use_contact_forces
        self._contact_cost_weight = contact_cost_weight
        self._healthy_reward = healthy_reward
        self._terminate_when_unhealthy = terminate_when_unhealthy
        self._healthy_z_range = healthy_z_range
        self._contact_force_range = contact_force_range
        self._reset_noise_scale = reset_noise_scale
        self._exclude_current_positions_from_observation = (
            exclude_current_positions_from_observation
        )
        self.full_goal_space = full_goal_space
        # self.goal_qpos = None # Will be changed later if full_goal_space is True
        # self.goal_tail = None

        if self._use_contact_forces:
            raise NotImplementedError("use_contact_forces not implemented.")

    def reset_with_specific_target_settings(self, rng, possible_goals):
        """Resets the environment to an initial state."""
        # Split the incoming PRNG key into three independent keys:
        # - rng1: for position noise
        # - rng2: for velocity noise
        # - rng : updated key for any further randomness downstream
        rng, rng1, rng2 = jax.random.split(rng, 3)

        # Define the uniform noise bounds for resetting
        low, hi = -self._reset_noise_scale, self._reset_noise_scale
        
        # ‘q’ (generalized positions) includes:
        #  - the ant’s world‑frame root position & orientation
        #  - all joint angles
        #  - (in this maze variant) the last two entries encode the target’s x,y coordinates
        # We take the default init_q and add small uniform noise in [low, hi] to each element.
        q = self.sys.init_q + jax.random.uniform(
            rng1, (self.sys.q_size(),), minval=low, maxval=hi
        )
        
        # ‘qd’ (generalized velocities) includes:
        #  - the root link’s linear & angular velocities
        #  - each joint’s angular velocity
        #  - (last two entries would correspond to target velocity, which we zero out later)
        # We draw standard normal noise and scale it by hi to jitter initial velocities.
        qd = hi * jax.random.normal(rng2, (self.sys.qd_size(),))

        # set the target q, qd
        # Sample a random goal position from the provided possible_goals array
        _, target = random_target_fn(possible_goals, rng)
        
        # Overwrite the last two entries of q with the chosen target’s [x, y]
        q = q.at[-2:].set(target)
        # Zero out the corresponding velocity entries so the goal doesn’t “drift”
        qd = qd.at[-2:].set(0)

        if self.full_goal_space:
            # # q is 17-dimensional. The first two entries are the ant’s position, while the last two entries are the target's position. We are intersted in the rest of the 13 entries.
            # self.goal_qpos = q[2:-2] # Unlike Numpy, this creates a copy by default.
            # print('self.goal_qpos.shape:', self.goal_qpos.shape)

            goal_qpos = q[2:-2]
            goal_qvel = jnp.zeros(14)
            goal_tail = jnp.concatenate([goal_qpos, goal_qvel])

        # Initialize Brax’s physics pipeline state with our perturbed q and qd
        pipeline_state = self.pipeline_init(q, qd)
        
        # Extract the agent’s observation vector (joint positions, velocities, and target location)
        obs = self._get_obs(pipeline_state)

        # Right after a reset, everything—reward, termination signal, and all diagnostic metrics—starts at zero.
        reward, done, zero = jnp.zeros(3)
        metrics = {
            "reward_forward": zero,
            "reward_survive": zero,
            "reward_ctrl": zero,
            "reward_contact": zero,
            "x_position": zero,
            "y_position": zero,
            "distance_from_origin": zero,
            "x_velocity": zero,
            "y_velocity": zero,
            "forward_reward": zero,
            "dist": zero,
            "success": zero,
            "success_easy": zero,
        }
        
        # Initialize auxiliary metadata for this new episode.
        # We’ll use 'seed' as a simple counter for how many steps have occurred
        info = {"seed": 0}
        if self.full_goal_space:
            info['goal_tail'] = goal_tail
        
        # Build the core Brax State object, which holds:
        #  - pipeline_state: the low‑level physics state from pipeline_init()
        #  - obs:        the agent’s observation vector
        #  - reward:     the immediate reward (0.0 on reset)
        #  - done:       termination flag (0.0 on reset)
        #  - metrics:    a dict of diagnostics, all zeroed out here
        state = State(pipeline_state, obs, reward, done, metrics)
        state.info.update(info)
        return state

    # The only difference between this method and the previous one is that this samples goals from the environment’s internal self.possible_goals that was configured at construction time.
    def reset(self, rng: jax.Array) -> State:
        """Resets the environment to an initial state."""

        rng, rng1, rng2 = jax.random.split(rng, 3)

        low, hi = -self._reset_noise_scale, self._reset_noise_scale
        q = self.sys.init_q + jax.random.uniform(
            rng1, (self.sys.q_size(),), minval=low, maxval=hi
        )
        qd = hi * jax.random.normal(rng2, (self.sys.qd_size(),))

        # set the target q, qd
        _, target = random_target_fn(self.possible_goals, rng)
        q = q.at[-2:].set(target)
        qd = qd.at[-2:].set(0)

        if self.full_goal_space:
            # # q is 17-dimensional. The first two entries are the ant’s position, while the last two entries are the target's position. We are intersted in the rest of the 13 entries.
            # self.goal_qpos = q[2:-2] # Unlike Numpy, this creates a copy by default.
            # print('self.goal_qpos.shape:', self.goal_qpos.shape)

            goal_qpos = q[2:-2]
            goal_qvel = jnp.zeros(14)
            goal_tail = jnp.concatenate([goal_qpos, goal_qvel])

        pipeline_state = self.pipeline_init(q, qd)
        obs = self._get_obs(pipeline_state)

        reward, done, zero = jnp.zeros(3)
        metrics = {
            "reward_forward": zero,
            "reward_survive": zero,
            "reward_ctrl": zero,
            "reward_contact": zero,
            "x_position": zero,
            "y_position": zero,
            "distance_from_origin": zero,
            "x_velocity": zero,
            "y_velocity": zero,
            "forward_reward": zero,
            "dist": zero,
            "success": zero,
            "success_easy": zero,
        }
        info = {"seed": 0}
        if self.full_goal_space:
            info['goal_tail'] = goal_tail

        state = State(pipeline_state, obs, reward, done, metrics)
        state.info.update(info)
        return state

    # Todo rename seed to traj_id
    def step(self, state: State, action: jax.Array) -> State:
        """Run one timestep of the environment's dynamics."""
        # Unpack the previous low‑level physics stat
        pipeline_state0 = state.pipeline_state
        
        # Advance the physics simulation by one step (possibly multiple sub‑frames)
        pipeline_state = self.pipeline_step(pipeline_state0, action)

        # Question: What does seed exactly represent? 
        # QUESTION: Where do we keep track of the number of steps? ANSWER: in EpisodeWrapper class
        # Update auxiliary 'seed' counter in state.info (if using 'steps' elsewhere)
        if "steps" in state.info.keys():
            # Only increment when state.info["steps"] is zero, otherwise keep the same
            seed = state.info["seed"] + jnp.where(state.info["steps"], 0, 1)
        else:
            seed = state.info["seed"]
        # info = {"seed": seed}
        state.info["seed"] = seed

        # 4. Compute the root‑link velocity: Δposition / Δtime
        #    Note: self.dt already reflects the total elapsed time for this step.
        velocity = (pipeline_state.x.pos[0] - pipeline_state0.x.pos[0]) / self.dt # self.dt is a method defined PipelineEnv class with a @property decorator
        
        # Reward for moving forward along the x‑axis
        forward_reward = velocity[0]

        # Check “health”: is the ant’s z‑height within the healthy range?
        min_z, max_z = self._healthy_z_range
        is_healthy = jnp.where(pipeline_state.x.pos[0, 2] < min_z, 0.0, 1.0)
        is_healthy = jnp.where(pipeline_state.x.pos[0, 2] > max_z, 0.0, is_healthy)
        
        # Survival reward: always give full reward if terminating on unhealthy,
        #    otherwise only when still healthy
        if self._terminate_when_unhealthy:
            healthy_reward = self._healthy_reward
        else:
            healthy_reward = self._healthy_reward * is_healthy
        
        # Control cost: penalize large actions (e.g., big torques)
        ctrl_cost = self._ctrl_cost_weight * jnp.sum(jnp.square(action))
        
        # Contact cost: not implemented here (set to zero)
        contact_cost = 0.0

        # Build the new observation and done flag
        obs = self._get_obs(pipeline_state)
        done = 1.0 - is_healthy if self._terminate_when_unhealthy else 0.0

        # Distance to goal and binary success indicators
        dist = jnp.linalg.norm(obs[:2] - obs[-2:])
        # if self.full_goal_space:
        #     dist = jnp.linalg.norm(obs[:2] - obs[29:31])

        success = jnp.array(dist < 0.5, dtype=float)
        success_easy = jnp.array(dist < 2., dtype=float)
        
        # Total reward: encourage closeness to goal, survival, and penalize control
        reward = -dist + healthy_reward - ctrl_cost - contact_cost

        # Update all metrics for logging/monitoring
        state.metrics.update(
            reward_forward=forward_reward,
            reward_survive=healthy_reward,
            reward_ctrl=-ctrl_cost,
            reward_contact=-contact_cost,
            x_position=pipeline_state.x.pos[0, 0],
            y_position=pipeline_state.x.pos[0, 1],
            distance_from_origin=math.safe_norm(pipeline_state.x.pos[0]),
            x_velocity=velocity[0],
            y_velocity=velocity[1],
            forward_reward=forward_reward,
            dist=dist,
            success=success,
            success_easy=success_easy,
        )
        # state.info.update(info)
        
        # Return a new State with updated physics, observation, reward, and done flag
        return state.replace(
            pipeline_state=pipeline_state, obs=obs, reward=reward, done=done
        )

    # QUESTION: What is the difference between pipline_state.q and pipeline_state.x.pos?
    def _get_obs(self, pipeline_state: base.State) -> jax.Array:
        """Observe ant body position and velocities."""
            # Extract all generalized positions _except_ the last two entries
            #    – pipeline_state.q is a 1‑D array of length Q, where:
            #        • q[:3]   = ant’s root (x,y,z) in world frame  
            #        • q[3:7]  = ant’s root orientation (quaternion)  
            #        • q[7:-2] = all joint angles  
            #        • q[-2:]  = the target’s (x,y) coordinates (we’ve hijacked these slots)
        qpos = pipeline_state.q[:-2]
        # Check the Mujoco documentation
        # Likewise, get all generalized velocities except target‑velocity slots
        #    – pipeline_state.qd has the same layout: root lin+ang vel, joint vel, then 2 target vel entries
        qvel = pipeline_state.qd[:-2]

        # Read the world‑frame position of the special “target body”
        #    – pipeline_state.x.pos has shape (n_bodies, 3)
        #    – We arranged in our XML that the very last body is a free‑floating “target”  
        #    – x.pos[-1] is its (x,y,z), so [:2] picks out only the x,y we care about
        target_pos = pipeline_state.x.pos[-1][:2] # QUESTION: Why are we using this value for the target instead of the last two entries of qpos?

        # qpos[0:2] are the ant’s world x,y; slicing them away makes obs translation‑invariant
        if self._exclude_current_positions_from_observation:
            qpos = qpos[2:]
        
        # # translational velocities (3), angular velocities of the torso (3), and angular velocities of the joints (8)
        # goal_qvel = jnp.zeros(14)

        # if self.full_goal_space:
        #     # qpos(15) + qvel(14) gives the current observation (29-dimensional vector). target_pos(2) + goal_qpos(13) + goal_qvel(14) gives the goal observation (29-dimensional vector).
        #     return jnp.concatenate([qpos] + [qvel] + [target_pos] + [self.goal_qpos] + [goal_qvel])
        
        return jnp.concatenate([qpos] + [qvel] + [target_pos])