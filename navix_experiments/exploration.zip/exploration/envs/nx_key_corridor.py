import jax
import navix as nx
import jax.numpy as jnp

from jax import Array
from flax import struct
from typing import Union
import jax.tree_util as jtu

from envs.nx_envs import Environment, Timestep, Door

from navix.states import State
from navix import register_env
from navix.spaces import Discrete
from navix.components import EMPTY_POCKET_ID, DISCARD_PILE_IDX, Directional, HasColour, Openable
from navix.rendering.cache import RenderingCache
from navix.entities import EntityIds, Player, Key, Ball
from navix.grid import random_directions, random_directions, random_colour, RoomsGrid

key_corridor_S3R1_coords = jnp.array([1,5], dtype=jnp.int32)

key_corridor_S3R2_coords = jnp.array([3,5], dtype=jnp.int32)

key_corridor_S3R3_coords = jnp.array([3,5], dtype=jnp.int32)

key_corridor_S4R3_coords = jnp.array([4,7], dtype=jnp.int32)

key_corridor_S6R3_coords = jnp.array([6,11], dtype=jnp.int32)

class gcrl_KeyCorridor(Environment):
    def _reset(self, key: Array, cache: Union[RenderingCache, None] = None) -> Timestep:
        n_rows_config = {3: 1, 5: 2}
        n_rows = n_rows_config.get(self.height, 3)
        room_size = (self.width - 3) // 3
        fixed_key = jax.random.PRNGKey(173567)
        k1, k2, k3, k4, k5, k6 = jax.random.split(fixed_key, num=6)

        # grid of rooms
        grid = RoomsGrid.create(n_rows, 3, (room_size, room_size))

        # key
        key_room_row = jax.random.randint(k1, (), minval=0, maxval=n_rows)
        key_pos = grid.position_in_room(
            key_room_row, jnp.asarray(0, dtype=jnp.int32), key=k1
        )
        key_colour = random_colour(k4)
        key_id = jnp.asarray(1)
        key_obj = Key.create(key_pos, key_colour, key_id)

        # agent
        pk_1, pk_2, pk_3 = jax.random.split(k2, num=3)
        agent_room_row = jax.random.randint(pk_1, (), minval=0, maxval=n_rows)
        agent_pos = grid.position_in_room(agent_room_row, jnp.asarray(1), key=pk_2)
        player = Player.create(
            agent_pos, random_directions(pk_3), pocket=EMPTY_POCKET_ID
        )

        # ball
        ball_room_row = jax.random.randint(k3, (), minval=0, maxval=n_rows)
        ball_pos = grid.position_in_room(ball_room_row, jnp.asarray(2), key=k4)

        # print(ball_pos)

        # ball = Ball.create(ball_pos, random_colour(k6), probability=jnp.asarray(0.0))

        # Doors
        doors = []
        for row in range(n_rows):
            k5, k6, k7, k8, k9 = jax.random.split(k5, num=5)
            # left corridor, right wall
            door_pos = grid.position_on_border(row, 2, 0, key=k5)
            requires, colour, open = jax.lax.cond(
                jnp.array_equal(row, ball_room_row),
                lambda: (key_id, key_colour, jnp.asarray(2)),
                lambda: (jnp.asarray(-1), random_colour(k5), jnp.asarray(0)),
            )
            doors.append(
                Door.create(
                    position=door_pos, requires=requires, colour=colour, open=open
                )
            )
            # right corridor, left wall
            door_pos = grid.position_on_border(row, 0, 1, key=k7)
            doors.append(
                Door.create(
                    position=door_pos,
                    requires=EMPTY_POCKET_ID,
                    colour=random_colour(k7),
                    open=jnp.asarray(0),
                )
            )
        for row in range(n_rows - 1):
            k9, k10, k11, k12 = jax.random.split(k9, num=4)
            # first col
            door_pos = grid.position_on_border(row, 0, 3, key=k9)
            doors.append(
                Door.create(
                    position=door_pos,
                    requires=EMPTY_POCKET_ID,
                    colour=random_colour(k10),
                    open=jnp.asarray(0),
                )
            )
            doors.append(
                Door.create(
                    position=door_pos,
                    requires=EMPTY_POCKET_ID,
                    colour=random_colour(k12),
                    open=jnp.asarray(0),
                )
            )
        doors = jtu.tree_map(lambda *x: jnp.stack(x), *doors)

        entities = {
            "player": player[None],
            "key": key_obj[None],
            "door": doors,
            # "goal": ball[None],
        }

        grid = grid.get_grid()
        grid = grid.at[
            1 + room_size : self.height - 1 : room_size + 1,
            1 + room_size + 1 : 1 + room_size + 1 + room_size,
        ].set(0)
        grid = grid.at[doors.position[:,0], doors.position[:,1]].set(0)

        state = State(
            key=key,
            grid=grid,
            cache=cache or RenderingCache.init(grid),
            entities=entities,
        )
        return Timestep(
            t=jnp.asarray(0, dtype=jnp.int32),
            observation=self.observation_fn(state),
            action=jnp.asarray(-1, dtype=jnp.int32),
            reward=jnp.asarray(0.0, dtype=jnp.float32),
            step_type=jnp.asarray(0, dtype=jnp.int32),
            state=state,
        )

def on_goal_reached_S3R1(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array(key_corridor_S3R1_coords, dtype=jnp.int32)), dtype=jnp.float32)

def on_goal_reached_S3R2(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array(key_corridor_S3R2_coords, dtype=jnp.int32)), dtype=jnp.float32)

def on_goal_reached_S3R3(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array(key_corridor_S3R3_coords, dtype=jnp.int32)), dtype=jnp.float32)

def on_goal_reached_S4R3(prev_state: State, action: Array, state: State) -> Array:
    """A reward function that returns 1 when the goal is reached, and 0 otherwise.

    Args:
        state (State): The current state of the game.

    Returns:
        Array: A scalar array `f32[]` with value 1 if the goal is reached, and 0 otherwise.
    """
    return jnp.asarray( jnp.all(state.entities['player'].position == jnp.array(key_corridor_S4R3_coords, dtype=jnp.int32)), dtype=jnp.float32)

def free(prev_state: State, action: Array, state: State) -> Array:
    """never terminate.

    Args:
        prev_state (State): The previous state of the game.
        action (Array): The action taken by the player.
        state (State): The current state of the game.

    Returns:
        Array: A boolean array indicating false everywhere."""
    return jnp.zeros_like(nx.events.on_ball_hit(state), dtype=jnp.bool_)


def symbolic(state: State) -> Array:
    """Fully observable grid with a symbolic state representation as originally \
    proposed in the MiniGrid environment.
    The symbol is a triple of (OBJECT_TAG, COLOUR_IDX, OPEN/CLOSED/LOCKED). The
    last layer might also contain the direction of the entity, for example, the
    direction of the agent.
    
    Args:
        state (State): The current state of the game.
        
    Returns:
        Array: A grid of integers, where each integer represents an entity, \
        represented as an array of shape `u8[H, W, 3]`, where `H` and `W` are the height \
        and width of the grid."""
    # initialise as all floors
    H, W = state.grid.shape
    obs = jnp.zeros((H, W, 3), dtype=jnp.uint8)
    wall_symbol = jnp.array([EntityIds.WALL, 5, 0], dtype=jnp.uint8)
    floor_symbol = jnp.array([EntityIds.FLOOR, 0, 0], dtype=jnp.uint8)
    obs = jnp.where(state.grid[..., None] == -1, wall_symbol, floor_symbol)

    # place entities
    for entity_class in state.entities:
        entity = state.entities[entity_class]
        tag = entity.tag
        # colour layer
        if isinstance(entity, HasColour):
            colour = entity.colour
        else:
            colour = jnp.zeros(entity.shape)
        # state layer
        if isinstance(entity, Openable):
            entity_state = (1 - entity.open)
            # entity_state = entity.open + (entity.requires != jnp.zeros(entity.shape))
        elif isinstance(entity, Directional):
            entity_state = entity.direction
        else:
            entity_state = jnp.zeros(entity.shape)
        entity_symbol = jnp.stack([tag, colour, entity_state], axis=-1, dtype=jnp.uint8)
        obs = obs.at[tuple(entity.position.T)].set(entity_symbol)
    
    return jnp.expand_dims(obs[:,:,0]*0.1 + obs[:,:,2]*0.01, axis=-1)

register_env(
    "Navix-KeyCorridorS3R1-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=3,
        width=7,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(3, 7, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached_S3R1),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)
register_env(
    "Navix-KeyCorridorS3R2-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=5,
        width=7,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(5, 7, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached_S3R2),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)

register_env(
    "Navix-KeyCorridorS3R3-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=7,
        width=7,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(7, 7, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached_S3R3),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)

register_env(
    "Navix-KeyCorridorS4R3-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=10,
        width=10,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(10, 10, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", on_goal_reached_S4R3),
        termination_fn=kwargs.pop("termination_fn", free),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)

register_env(
    "Navix-KeyCorridorS5R3-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=13,
        width=13,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(13, 13, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", nx.rewards.on_goal_reached),
        termination_fn=kwargs.pop("termination_fn", nx.terminations.on_goal_reached),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)

register_env(
    "Navix-KeyCorridorS6R3-v0",
    lambda *args, **kwargs: gcrl_KeyCorridor.create(
        height=16,
        width=16,
        observation_fn=kwargs.pop("observation_fn", symbolic),
        observation_space=kwargs.pop("observation_space", Discrete.create(
                n_elements=9,
                shape=(16, 16, 1),
                dtype=jnp.float32,
            )),
        reward_fn=kwargs.pop("reward_fn", nx.rewards.on_goal_reached),
        termination_fn=kwargs.pop("termination_fn", nx.terminations.on_goal_reached),
        action_set = nx.actions.DEFAULT_ACTION_SET[:6],
        *args,
        **kwargs,
    ),
)