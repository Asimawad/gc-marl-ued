import jax
import jax.numpy as jnp

from flax import struct # Flax’s lightweight “dataclass” system that makes your Python classes into immutable, JAX‑friendly PyTrees.
from brax.envs.base import Wrapper # A Wrapper is a thin base class that you subclass when you want to wrap an environment—i.e. intercept (and possibly modify) its reset, step, or other methods.

# All four are type hints used to annotate function signatures and data structures, making your code more self‑documenting and enabling better IDE/editor support
#   Callable: Use when you want to say “this argument should be a function.”
#   Dict: A generic mapping type.
#   Optional: Shorthand for “this could be None or else the given type.”
#   Tuple: A fixed‑length, heterogeneous sequence type.
from typing import Callable, Dict, Optional, Tuple

import matplotlib.pyplot as plt

# patches contains classes for drawing shape “patches” in your plots: Rectangle, Circle, Polygon, Arrow, etc.
import matplotlib.patches as patches

# ListedColormap: Build a discrete colormap from an explicit list of colors.
# BoundaryNorm: Takes a list of numeric “boundaries” and a colormap, and maps any input value into the correct discrete color index.
from matplotlib.colors import ListedColormap, BoundaryNorm
    
# from https://github.com/google/brax/blob/main/brax/envs/wrappers/training.py

class EpisodeWrapper(Wrapper):
    """Maintains episode step count and sets done at episode end."""
    def __init__(self, env, episode_length, action_repeat):
        super().__init__(env)
        self.episode_length = episode_length # maximum RL steps per episode
        self.action_repeat = action_repeat # physics frames per RL action

    def reset(self, rng):
        # Call inner env's reset to get initial state
        state = self.env.reset(rng)
        # Initialize step counter (one per parallel env) to zero
        state.info['steps'] = jnp.zeros(rng.shape[:-1])
        # Initialize truncation flags to zero (no truncation yet)
        state.info['truncation'] = jnp.zeros(rng.shape[:-1])
        return state
    
    # Similar to reset(), but for envs supporting specific target goals
    def reset_with_specific_target_settings(self, rng, possible_goals):
        state = self.env.reset_with_specific_target_settings(rng, possible_goals)
        state.info['steps'] = jnp.zeros(rng.shape[:-1])
        state.info['truncation'] = jnp.zeros(rng.shape[:-1])
        return state
    
    def step(self, state, action):
        
        # Inner function to apply one physics step and return (state, reward)
        def f(state, _):
            nstate = self.env.step(state, action)
            return nstate, nstate.reward

        # Repeat the same action for `action_repeat` frames via scan
        state, rewards = jax.lax.scan(f, state, (), self.action_repeat)
        # Sum up the rewards from each repeated frame into a single reward
        state = state.replace(reward=jnp.sum(rewards, axis=0))
        # Update the episode step counter
        steps = state.info['steps'] + self.action_repeat
        # Prepare helper tensors for done logic
        one = jnp.ones_like(state.done)
        zero = jnp.zeros_like(state.done)
        episode_length = jnp.array(self.episode_length, dtype=jnp.int32)
        
        # Mark done if we've reached/exceeded the max episode length
        done = jnp.where(steps >= episode_length, one, state.done)
        # Mark truncation flag: 1 if ended due to length (and not env termination)
        # QUESTION: why will happen if state.done is already 1? Why not just set it to 1?
        # GPT Answer: because the reason for ending is something else instead of truncation.
        state.info['truncation'] = jnp.where(
            steps >= episode_length,
            1 - state.done, # true only when env.done was 0 before
            zero
        )
        # Store updated step count
        state.info['steps'] = steps
        # Return new state with updated done flag
        return state.replace(done=done)

class VmapWrapper(Wrapper):
    """Vectorizes Brax env."""
    def __init__(self, env, batch_size = None):
        # Initialize with underlying env and optional batch size
        super().__init__(env)
        self.batch_size = batch_size

    def reset(self, rng):
        # If batch_size given, split RNG into that many subkeys
        if self.batch_size is not None:
            rng = jax.random.split(rng, self.batch_size)
        # Vectorize the reset call across all RNGs
        return jax.vmap(self.env.reset)(rng)

    def reset_with_specific_target_settings(self, rng, possible_goals):
        # Split RNG if batched, then vmap reset with specific goals
        if self.batch_size is not None:
            rng = jax.random.split(rng, self.batch_size)
        return jax.vmap(self.env.reset_with_specific_target_settings, in_axes=(0, None))(rng, possible_goals)

    def step(self, state, action: jax.Array):
        # Vectorize the step call across the batch of states/actions
        return jax.vmap(self.env.step)(state, action)
    
class AutoResetWrapper(Wrapper):
    """Automatically resets Brax envs that are done."""

    def reset(self, rng: jax.Array):
        # Use the base reset to get an initial State
        # `self.env` comes from the superclass; it's set when this wrapper is constructed
        state = self.env.reset(rng) # What do you mean by self.env? It wasn't initialized with an init function.
        state.info['first_pipeline_state'] = state.pipeline_state
        state.info['first_obs'] = state.obs
        return state
    
    def reset_with_specific_target_settings(self, rng, possible_goals):
        # Same storing logic as above
        state = self.env.reset_with_specific_target_settings(rng, possible_goals)
        state.info['first_pipeline_state'] = state.pipeline_state
        state.info['first_obs'] = state.obs
        return state

    def step(self, state, action):
        # If we're already tracking per‑episode steps, zero them out for any just‑done envs
        if 'steps' in state.info:
            steps = state.info['steps']
            # wherever done==True, restart the counter to 0
            steps = jnp.where(state.done, jnp.zeros_like(steps), steps)
            state.info.update(steps=steps)

        # Clear the done flag so the inner env.step always runs fresh
        state = state.replace(done=jnp.zeros_like(state.done))

        # Step the inner environment
        state = self.env.step(state, action)

        def where_done(x, y):
            done = state.done
            # For batched arrays, reshape done to broadcast over all dims
            if done.shape:
                done = jnp.reshape(done, [x.shape[0]] + [1] * (len(x.shape) - 1))  # type: ignore
            # Wherever done==True, pick the “old” value x; otherwise pick the new y
            return jnp.where(done, x, y)

        # Reconstruct the pipeline state:
        pipeline_state = jax.tree.map(
            where_done, state.info['first_pipeline_state'], state.pipeline_state
        )

        # Reconstruct the observation:
        obs = where_done(state.info['first_obs'], state.obs)
        
        # Return a new State with reset sub‑envs baked in
        return state.replace(pipeline_state=pipeline_state, obs=obs)
  
@struct.dataclass
class EvalMetrics:
  """Dataclass holding evaluation metrics for Brax.

  Attributes:
      episode_metrics: Aggregated episode metrics since the beginning of the episode.
      active_episodes: Boolean vector tracking which episodes are not done yet.
      episode_steps: Integer vector tracking the number of steps in the episode.
  """

  episode_metrics: Dict[str, jax.Array]
  active_episodes: jax.Array
  episode_steps: jax.Array

class EvalWrapper(Wrapper):
    """Brax env with eval metrics."""
    # Delegate to the wrapped environment’s reset to get a fresh State
    def reset(self, rng):
        reset_state = self.env.reset(rng)
        
        # Ensure there’s a 'reward' entry in the env’s own metrics dict
        #    so that tree_map below sees it.  Use the raw reset reward.
        reset_state.metrics['reward'] = reset_state.reward
        
        # Build a new EvalMetrics object to track:
        #    - episode_metrics: zeros for every metric key in reset_state.metrics
        #    - active_episodes: a ones vector (all envs start active)
        #    - episode_steps: zeros vector (no steps taken yet)
        eval_metrics = EvalMetrics(
        episode_metrics=jax.tree_util.tree_map(jnp.zeros_like, reset_state.metrics), # For each leaf array in reset_state.metrics, create a same-shaped zero array
            active_episodes=jnp.ones_like(reset_state.reward), # Shape (batch_size,): 1 meaning “this episode is active”
            episode_steps=jnp.zeros_like(reset_state.reward), # Shape (batch_size,): zero step count so far
        )
        
        # Store the EvalMetrics in the State’s .info so step() can update it
        reset_state.info['eval_metrics'] = eval_metrics
        return reset_state

    # Same logic as previous function
    def reset_with_specific_target_settings(self, rng, possible_goals):
        reset_state = self.env.reset_with_specific_target_settings(rng, possible_goals)
        reset_state.metrics['reward'] = reset_state.reward
        eval_metrics = EvalMetrics(
            episode_metrics=jax.tree_util.tree_map(jnp.zeros_like, reset_state.metrics),
            active_episodes=jnp.ones_like(reset_state.reward),
            episode_steps=jnp.zeros_like(reset_state.reward),
        )
        reset_state.info['eval_metrics'] = eval_metrics
        return reset_state

    def step(self, state, action):
        #  Extract the EvalMetrics from the incoming State
        state_metrics = state.info['eval_metrics']
        #    Sanity check we got the right container
        if not isinstance(state_metrics, EvalMetrics):
            raise ValueError(f'Incorrect type for state_metrics: {type(state_metrics)}')
        #    Remove it so the inner env.step won’t overwrite it
        del state.info['eval_metrics']

        # Take one step in the wrapped environment
        nstate = self.env.step(state, action)
        #    Seed the 'reward' metric again so nstate.metrics has a 'reward' key
        nstate.metrics['reward'] = nstate.reward
        
        # Update the step‐count for each env:
        #    - If still active, read the latest counter from nstate.info['steps']
        #    - If already finished, freeze the old step count
        episode_steps = jnp.where(
            state_metrics.active_episodes,
            nstate.info['steps'],
            state_metrics.episode_steps,
        )
        
        # Accumulate each metric key only for active envs:
        #    new_sum = old_sum + (new_value * active_flag)
        episode_metrics = jax.tree_util.tree_map(
            lambda a, b: a + b * state_metrics.active_episodes,
            state_metrics.episode_metrics,
            nstate.metrics,
        )

        # Update the active_episodes mask:
        #    remains 1 until done==1, then becomes 0 and stays 0
        active_episodes = state_metrics.active_episodes * (1 - nstate.done)

        # Pack everything into a fresh EvalMetrics (immutable container)
        eval_metrics = EvalMetrics(
            episode_metrics=episode_metrics,
            active_episodes=active_episodes,
            episode_steps=episode_steps,
        )

        # Store back in nstate.info so future steps keep updating it
        nstate.info['eval_metrics'] = eval_metrics
        return nstate