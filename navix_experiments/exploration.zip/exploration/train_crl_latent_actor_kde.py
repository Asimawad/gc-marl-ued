import os
import jax
import flax  # Neural network library for JAX. Used here for defining models and TrainState.
import tyro  # Library for creating command-line interfaces from type-annotated Python functions/classes.
import time
import optax  # Optimization library for JAX, used for defining optimizers (e.g., Adam).
import wandb  # Weights & Biases library for experiment tracking and visualization.
import pickle  # Used for serializing and de-serializing Python objects (saving/loading parameters).
import random  # Standard Python library for generating random numbers (used for seeding).
import wandb_osh  # Weights & Biases Offline Sync Hook - potentially for syncing offline runs.
import numpy as np  # Standard NumPy library, often used for initial setup before converting to JAX arrays.
import jax.numpy as jnp
import flax.linen as nn  # Flax's module system for building neural networks layer by layer.

from etils import epath   # Utility library (part of TFDS) for handling file paths in a cross-platform way.
from dataclasses import dataclass  # Standard Python library for creating simple data classes (like Args).
from typing import NamedTuple, Any  # For defining structured data types (Transition) and general type hints.
from wandb_osh.hooks import TriggerWandbSyncHook  # Specific hook from wandb_osh for offline syncing.
from flax.training.train_state import TrainState  # Flax utility class to bundle model parameters, apply function, and optimizer state.
# Note: variance_scaling is imported but not directly used in this snippet. It's likely used within models.py.
from flax.linen.initializers import variance_scaling

from evaluator import CrlEvaluator  # Class for running evaluation episodes.
from buffer import TrajectoryUniformSamplingQueue  # Custom replay buffer implementation.
from envs.wrappers import EpisodeWrapper, VmapWrapper, AutoResetWrapper  # Wrappers to modify environment behavior (e.g., episode length, vectorization, auto-reset).




# === Configuration & Setup ===

@dataclass  # Decorator to automatically generate __init__, __repr__, etc. for this class.
class Args:
    """
    Dataclass holding all configuration options and hyperparameters for the training run.
    These arguments can be set via the command line using `tyro`.
    """
    # --- Experiment Setup ---
    alg_name: str = os.path.basename(__file__)[len("train"): -len(".py")] # Algorithm name, defaults to the script's filename without '.py'.
    exp_no: str = "test" # Experiment number, defaults to 'test'.
    # seed: int = 1 # Random seed for reproducibility
    n_seeds: int = 1 # Number of random seeds to use for the experiment.
    torch_deterministic: bool = True # Flag related to PyTorch determinism (might be legacy or unused in pure JAX).
    cuda: bool = True # Flag indicating if CUDA (GPU) is intended to be used (JAX handles device placement).
    track: bool = False # Whether to enable experiment tracking with Weights & Biases.
    wandb_project_name: str = "sampling_goals" # Name of the WandB project.
    wandb_entity: str = 'ahmed-turkman-aims-south-africa' # WandB username or team name.
    wandb_mode: str = 'online' # WandB mode: 'online', 'offline', or 'disabled'.
    wandb_dir: str = '.'       # Directory where WandB logs are stored.
    # wandb_group: str = 'hardest_maze_crl_kde_01' # WandB group name to organize runs.
    capture_video: bool = False     # Flag to enable video recording of evaluation episodes (likely requires additional setup).
    checkpoint: bool = False    # Whether to save model checkpoints during training.

    #environment specific arguments
    env_id: str = "ant u_maze" # Identifier for the environment to be used (e.g., "ant", "ant_maze u_maze").
    episode_length: int = 1000 # Maximum number of steps per episode.
    # to be filled in runtime
    obs_dim: int = 0 # Dimensionality of the core state observation (excluding goal). To be filled later.
    goal_start_idx: int = 0 # Start index of the goal portion within the full observation vector. To be filled later.
    goal_end_idx: int = 0 # End index (exclusive) of the goal portion within the full observation vector. To be filled later.
    full_goal_space: bool = False # Flag indicating whether to use the goal space as the full observation space.

    # Algorithm specific arguments
    total_env_steps: int = 25000000 # Total number of environment interactions for the entire training run.
    num_epochs: int = 50 # Number of training epochs. Each epoch consists of multiple training steps and an evaluation phase.
    num_envs: int = 1024 # Number of parallel environments to run for data collection.
    num_eval_envs: int = 128 # Number of parallel environments to run for evaluation.
    actor_lr: float = 3e-4 # Learning rate for the actor network optimizer.
    critic_lr: float = 3e-4 # Learning rate for the critic network optimizer.
    alpha_lr: float = 3e-4 # Learning rate for the SAC entropy coefficient (alpha) optimizer.
    batch_size: int = 256  # Batch size for SGD updates. Note: This is the batch size per SGD step, the buffer sampling might be larger. NOTE: Need to get deeper into this.
    rep_size: int = 64  # Dimensionality of the latent representation space for states, actions, and goals.
    gamma: float = 0.99 # Discount factor for future rewards in HER goal relabeling.
    logsumexp_penalty_coeff: float = 0.1 # Coefficient for the LogSumExp regularization term in the critic loss (to prevent representation collapse). NOTE: Need to come to this point again.
    small_networks: bool = False # Flag to use smaller network architectures (defined in models.py).

    # --- Replay Buffer Arguments ---
    max_replay_size: int = 10000 # Maximum number of *trajectories* (sequences) the replay buffer can hold.
    min_replay_size: int = 1000  # Minimum number of *trajectories* required in the buffer before starting training.
    
    unroll_length: int  = 62 # Length of the trajectory sequences collected in each `actor_step` and stored in the buffer.


    # to be filled in runtime
    # These are calculated based on other arguments after parsing.
    env_steps_per_actor_step : int = 0 # Calculated: num_envs * unroll_length. How many env steps happen per collection/training cycle.
    """number of env steps per actor step (computed in runtime)"""
    num_prefill_env_steps : int = 0  # Calculated: min_replay_size * unroll_length * num_envs. Total env steps for prefilling buffer.
    """number of env steps to fill the buffer before starting training (computed in runtime)"""
    num_prefill_actor_steps : int = 0 # Calculated: ceil(min_replay_size / unroll_length). How many collection steps for prefilling.
    """number of actor steps to fill the buffer before starting training (computed in runtime)"""
    num_training_steps_per_epoch : int = 0 # Calculated based on total steps, prefill steps, epochs, and steps per actor step.
    """the number of training steps per epoch(computed in runtime)"""

@flax.struct.dataclass # Makes this class usable in JAX transformations (jit, vmap) and as a Pytree.
class TrainingState:
    """Contains training state for the learner"""
    env_steps: jnp.ndarray # Counter for the total number of environment steps taken.
    gradient_steps: jnp.ndarray # Counter for the total number of gradient update steps performed.
    actor_state: TrainState # Flax TrainState holding the actor's parameters and optimizer state.
    critic_state: TrainState # Flax TrainState holding the critic's (SA-encoder, G-encoder) parameters and optimizer state.
    alpha_state: TrainState  # Flax TrainState holding the SAC log_alpha parameter and its optimizer state.

class Transition(NamedTuple):
    """
    A container for storing a single step transition data collected from the environment.
    Used as the structure for data samples in the replay buffer.
    """
    observation: jnp.ndarray # Observation from the environment at time t.
    action: jnp.ndarray # Action taken at time t.
    extras: jnp.ndarray = () # A tuple or dictionary to hold any additional data (like RNG seeds used for HER).


def save_params(path: str, params: Any):
    """Saves parameters in pickle format to the specified path."""
    """Saves parameters in flax format."""
    with epath.Path(path).open('wb') as fout: # Use epath for robust path handling.
        fout.write(pickle.dumps(params)) # Serialize the parameters using pickle and write to file.

# === Main Execution Block ===
if __name__ == "__main__":

    # --- Argument Parsing & Calculation ---
    # Parse command-line arguments using `tyro`, populating the `Args` dataclass.
    args = tyro.cli(Args)

    # Calculate derived arguments based on the parsed command-line/default arguments.
    # Total environment steps collected in one multi-environment parallel step.
    args.env_steps_per_actor_step = args.num_envs * args.unroll_length
    # Total environment steps needed to initially fill the replay buffer to its minimum required size.
    # NOTE: This calculation seems slightly off, usually prefill steps depend on unroll_length too.
    # A more common calculation would be: args.min_replay_size * args.unroll_length * args.num_envs
    args.num_prefill_env_steps = args.min_replay_size * args.num_envs
    # Number of *parallel actor steps* (data collection steps) required to prefill the buffer.
    args.num_prefill_actor_steps = np.ceil(args.min_replay_size / args.unroll_length) # Uses ceil to ensure at least min_replay_size steps are collected.
    # Number of training steps (SGD updates batches) to perform within each epoch.
    # Calculated by taking total steps, subtracting prefill, dividing by steps per epoch.
    args.num_training_steps_per_epoch = (args.total_env_steps - args.num_prefill_env_steps) // (args.num_epochs * args.env_steps_per_actor_step)

    if args.full_goal_space:
        wandb_group: str = args.env_id + '_' + args.alg_name + '_' + "full_" + args.exp_no
    else:
        wandb_group: str = args.env_id + '_' + args.alg_name + '_' + args.exp_no

    for seed in range(args.n_seeds):

        print('\n' + '-' * 80)
        print('starting a new run...')
        print('-' * 80, end='\n\n')

        # --- Run Setup (Naming, Tracking, Checkpointing) ---
        run_name = f"{args.env_id}_{args.alg_name}_{args.exp_no}_{seed}_{int(time.time())}"


        # Initialize Weights & Biases if tracking is enabled.
        if args.track:

            # Set a default WandB group name if none is provided.
            if wandb_group ==  '.':
                wandb_group = 'normal'
                
            # Initialize the WandB run.
            wandb.init(
                project=args.wandb_project_name, # Project name on WandB.
                entity=args.wandb_entity,        # User/team entity on WandB.
                mode=args.wandb_mode,            # 'online', 'offline', or 'disabled'.
                group=wandb_group,          # Group name for organizing runs.
                dir=args.wandb_dir,              # Local directory for WandB logs.
                config=vars(args),               # Log all hyperparameters from the Args dataclass.
                name=run_name,                   # Assign the unique run name.
                monitor_gym=True,                # Enable automatic WandB logging for Gym environments (if applicable).
                save_code=True,                  # Save the main script code to WandB.
            )

            # Configure WandB Offline Sync Hook if running in offline mode.
            if args.wandb_mode == 'offline':
                wandb_osh.set_log_level("ERROR") # Set log level for the offline sync hook.
                trigger_sync = TriggerWandbSyncHook() # Create a hook to trigger synchronization later.


        # Create a directory for saving model checkpoints if checkpointing is enabled.
        if args.checkpoint:
            from pathlib import Path # Use pathlib for cleaner path manipulation.
            # Define the path relative to the WandB directory and run name.
            save_path = Path(args.wandb_dir) / Path(run_name)
            # Create the directory.
            os.mkdir(path=save_path)

        # --- Seeding ---
        # Seed Python's built-in random number generator.
        random.seed(seed)
        # Seed NumPy's random number generator.
        np.random.seed(seed)
        # Create the master JAX PRNG key using the specified seed.
        key = jax.random.PRNGKey(seed)
        # Split the master key into sub-keys for different components to ensure independence.
        key, buffer_key, env_key, eval_env_key, actor_key, sa_key, g_key = jax.random.split(key, 7)
        
        # Environment setup
        # Conditionally import and initialize the environment based on the `env_id` argument.
        if args.env_id == "ant": 
            from envs.ant import Ant # Import the Ant environment class.
            # Initialize the Ant environment.
            env = Ant(
                backend="spring", # Specify the physics backend (e.g., "spring", "mjx").
                exclude_current_positions_from_observation=False, # Whether to include root body xy position in obs.
                terminate_when_unhealthy=False, # Whether episodes end if the ant falls over. Set to False for exploration tasks.
            )
            # Set environment-specific dimensions based on the known Ant structure.
            args.obs_dim = 29       # Dimensionality of the non-goal part of the observation.
            args.goal_start_idx = 0 # Index where goal information starts in the observation (here, it's part of the main obs).
            args.goal_end_idx = 2   # Index where goal information ends (exclusive). Assumes goal is the first 2 elements (xy position).

        elif "maze" in args.env_id and "ant" in args.env_id:
            from envs.ant_maze import AntMaze # Import the AntMaze environment class.
            # Initialize the AntMaze environment.
            env = AntMaze(
                backend="spring", # Physics backend.
                exclude_current_positions_from_observation=False, # Include root xy in obs.
                terminate_when_unhealthy=False, # Don't terminate if unhealthy (important for maze tasks).
                maze_layout_name=args.env_id[4:], # Extract maze layout name (e.g., "u_maze") from the env_id string.
                full_goal_space=args.full_goal_space, # Whether to use full goal space.
            )
            # Set environment-specific dimensions.
            args.obs_dim = 29       # Ant's base observation dimension.
            args.goal_start_idx = 0 # Index where goal information *relative to the goal part of the observation* starts.
            args.goal_end_idx = 2   # Index where goal information *relative to the goal part of the observation* ends.
                                    # Goal information (xy) seems appended later or handled differently in wrappers.
                                    # Let's re-evaluate this comment based on the wrapper code later.
                                    # The AntMaze._get_obs concatenates target_pos at the end.
                                    # So these indices seem incorrect based on ant_maze.py
                                    # It should likely be args.obs_dim = 29, goal_start_idx = 29, goal_end_idx = 31
            if args.full_goal_space:
                args.goal_end_idx = 29

        # ... (Code for other env_ids would follow a similar pattern) ...

        elif args.env_id == "ant_push":
            from envs.ant_push import AntPush
            env = AntPush(
                backend="mjx",
                exclude_current_positions_from_observation=False,
                terminate_when_unhealthy=True,
            )

            args.obs_dim = 31
            args.goal_start_idx = 0
            args.goal_end_idx = 2
        
        elif args.env_id == "ant_ball":
            from envs.ant_ball import AntBall

            env = AntBall(backend="spring", terminate_when_unhealthy=False)

            args.obs_dim = 31
            args.goal_start_idx = -4
            args.goal_end_idx = -2

        elif args.env_id == "humanoid_standup":
            from envs.humanoid_standup import HumanoidStandup

            env=HumanoidStandup(backend="spring")

            args.obs_dim = 244
            args.goal_start_idx = 0
            args.goal_end_idx = 1
        
        elif args.env_id == "humanoid":
            from envs.humanoid import Humanoid

            env=Humanoid(backend="spring", terminate_when_unhealthy=False)

            args.obs_dim = 268
            args.goal_start_idx = 0
            args.goal_end_idx = 3
        
        elif args.env_id == "humanoid_easy":
            from envs.humanoid_easy import HumanoidEasy

            env=HumanoidEasy(backend="spring", terminate_when_unhealthy=False)

            args.obs_dim = 268
            args.goal_start_idx = 0
            args.goal_end_idx = 3

        elif "maze" in args.env_id and "humanoid" in args.env_id:
            from envs.humanoid_maze import HumanoidMaze
            
            env=HumanoidMaze(backend="spring",  maze_layout_name=args.env_id[9:], terminate_when_unhealthy=False)
            
            args.obs_dim = 268
            args.goal_start_idx = 0
            args.goal_end_idx = 3

        elif args.env_id == "pusher":
            from envs.pusher import Pusher

            env=Pusher(backend="generalized", kind="hard")
            
            args.obs_dim = 20
            args.goal_start_idx = 10
            args.goal_end_idx = 13
            
        elif args.env_id == "pusher2":
            from envs.pusher2 import Pusher2
            
            env=Pusher2(backend="generalized")

            args.obs_dim = 23
            args.goal_start_idx = 10
            args.goal_end_idx = 16
        
        else:
            raise NotImplementedError

    # --- Environment Wrapping ---
        # Apply wrappers to the base environment to add functionality.
        # EpisodeWrapper: Limits episode length and potentially handles action repeats.
        env = EpisodeWrapper(env, args.episode_length, action_repeat=1)
        # VmapWrapper: Vectorizes the environment, enabling simultaneous execution of multiple instances (`args.num_envs`).
        # This modifies env.reset and env.step to expect/return batched states, actions, keys, etc.
        env = VmapWrapper(env)
        # AutoResetWrapper: Automatically resets individual environments within the vectorized batch when they reach a 'done' state.
        env = AutoResetWrapper(env)

        # --- Environment Properties and JIT Compilation ---
        # Get the observation and action sizes from the (wrapped) environment.
        # These methods are likely provided by the VmapWrapper or one of the base env classes.
        obs_size = env.observation_size # Total size of the observation vector (including state and goal). [ANSWERED: one of them is the full observation size]
        action_size = env.action_size   # Dimensionality of the action space.
        # Create an array of JAX PRNG keys, one for each parallel environment instance.
        env_keys = jax.random.split(env_key, args.num_envs)

        # JIT (Just-In-Time) compile the environment's step and reset functions for significant speedup.
        # JAX compiles these functions to highly optimized machine code (XLA) the first time they are called.
        env.step = jax.jit(env.step)
        env.reset = jax.jit(env.reset)

        # --- Initial Environment State ---
        # Perform the initial reset of all parallel environments using the generated keys.
        # `env_state` will contain the batched initial states (pipeline_state, obs, reward, done, metrics, info)
        # for all `args.num_envs` environments.
        env_state = env.reset(env_keys)

        # --- Model Selection ---
        # Conditionally import either the standard or smaller network architectures based on the `small_networks` argument.
        if args.small_networks:
            from models import small_Actor as Actor, small_SA_encoder as SA_encoder, small_G_encoder as G_encoder
        else:
            from models import Actor, SA_encoder, G_encoder
        
        # --- Network Setup and Initialization ---

        # Actor Network
        # Instantiate the Actor network model.
        actor = Actor(action_size=action_size)
        # Create the Actor's training state using `TrainState.create`. This bundles:
        #   - apply_fn: The function to call for a forward pass (actor.apply).
        #   - params: Initial parameters obtained by calling `actor.init`.
        #             `actor.init` requires dummy input matching the expected input shape:
        #               - State: `np.ones([1, args.obs_dim])` - Batch size 1, obs dimension (state part only).
        #               - Goal Representation: `np.ones([1, args.rep_size])` - Batch size 1, latent representation size.
        #   - tx: The optimizer (Adam) configured with the actor learning rate.
        actor_state = TrainState.create(
            apply_fn=actor.apply,
            params=actor.init(actor_key, np.ones([1, args.obs_dim]), np.ones([1, args.rep_size])),
            tx=optax.adam(learning_rate=args.actor_lr)
        )

        # Critic Networks (State-Action Encoder and Goal Encoder)
        # Instantiate the State-Action (SA) encoder model.
        sa_encoder = SA_encoder(rep_size=args.rep_size)
        # Initialize the SA-encoder parameters using dummy inputs.
        #   - State: `np.ones([1, args.obs_dim])`
        #   - Action: `np.ones([1, action_size])`
        sa_encoder_params = sa_encoder.init(sa_key, np.ones([1, args.obs_dim]), np.ones([1, action_size]))

        # Instantiate the Goal (G) encoder model.
        g_encoder = G_encoder(rep_size=args.rep_size)
        # Initialize the G-encoder parameters using a dummy goal input.
        # The goal input dimension is derived from the goal indices in the observation vector.
        #   - Goal: `np.ones([1, args.goal_end_idx - args.goal_start_idx])`
        g_encoder_params = g_encoder.init(g_key, np.ones([1, args.goal_end_idx - args.goal_start_idx]))

        # Create the Critic's training state.
        # Note: `apply_fn` is None because the critic involves applying two separate models (sa_encoder, g_encoder).
        # The forward pass logic is handled directly within the `update_critic` function.
        # The parameters are stored in a dictionary.
        critic_state = TrainState.create(
            apply_fn=None, # No single apply function for the combined critic.
            params={"sa_encoder": sa_encoder_params, "g_encoder": g_encoder_params}, # Store params for both encoders.
            tx=optax.adam(learning_rate=args.critic_lr), # Optimizer for critic parameters.
        )

        # --- SAC Entropy Coefficient (Alpha) Setup ---
        # Define the target entropy for the SAC algorithm (heuristic based on action space size).
        target_entropy = -0.5 * action_size
        # Initialize the logarithm of alpha (common practice for stability and ensuring positivity after exp).
        log_alpha = jnp.asarray(0.0, dtype=jnp.float32)
        # Create a TrainState for alpha.
        # `apply_fn` is None as alpha is just a parameter, not a network.
        alpha_state = TrainState.create(
            apply_fn=None,
            params={"log_alpha": log_alpha}, # The parameter to be optimized.
            tx=optax.adam(learning_rate=args.alpha_lr), # Optimizer for alpha.
        )

        # --- JIT Compile Network Apply Functions ---
        # JIT-compile the `apply` methods of the instantiated networks for performance.
        # This speeds up forward passes during both training and inference (evaluation/data collection).
        actor.apply = jax.jit(actor.apply)
        sa_encoder.apply = jax.jit(sa_encoder.apply)
        g_encoder.apply = jax.jit(g_encoder.apply)
        
        # --- Initialize Overall Training State ---
        # Create the main TrainingState dataclass instance.
        # This bundles all network states (actor, critic, alpha) and counters (env_steps, gradient_steps).
        # This single object will be passed around and updated throughout the training loop.
        training_state = TrainingState(
            env_steps=jnp.zeros(()),
            gradient_steps=jnp.zeros(()),
            actor_state=actor_state,
            critic_state=critic_state,
            alpha_state=alpha_state,
        )

    # === Replay Buffer Setup ===

        # Create dummy observation and action arrays with the correct shapes and dtypes.
        # These are used to define the structure of the data that the replay buffer will store.
        dummy_obs = jnp.zeros((obs_size,))
        dummy_action = jnp.zeros((action_size,))

        # Create a dummy Transition object. This serves as a template for the buffer,
        # defining the data structure (a NamedTuple) and the dtypes of its elements.
        # The structure includes observation, action, and an 'extras' dictionary which
        # here holds a placeholder for 'seed' (used for HER future sampling identification).
        dummy_transition = Transition(
            observation=dummy_obs,
            action=dummy_action,
            extras={
                "state_extras": { # Nested dictionary structure for extra information.
                    "seed": 0.0, # Placeholder for trajectory identifier seed.
                }        
            },
        )

        # Helper function to JIT-compile the insert and sample methods of a buffer object.
        # This avoids repeatedly JIT-compiling them inside the training loop.
        def jit_wrap(buffer):
            buffer.insert = jax.jit(buffer.insert)
            buffer.sample = jax.jit(buffer.sample)
            return buffer
        
        # Instantiate the custom replay buffer `TrajectoryUniformSamplingQueue`.
        replay_buffer = jit_wrap( # Apply the JIT wrapper to the instance.
                TrajectoryUniformSamplingQueue(
                    max_replay_size=args.max_replay_size, # Maximum number of sequences (trajectories) to store. NOTE: Make sure it is the number of sequences not number of steps / transitions.
                    dummy_data_sample=dummy_transition, # Provide the dummy transition as a template.
                    sample_batch_size=args.batch_size,  # Batch size for sampling *transitions* (after processing sequences). NOTE: Need to know how the batch size is used specifically.
                                                        # Note: The buffer samples sequences first, then processes them.
                    num_envs=args.num_envs,             # Number of parallel environments used for data collection.
                    # sequence_length: This parameter in the buffer determines the shape for sampling,
                    # specifically for creating the indices matrix in `buffer.sample`.
                    # is designed, possibly to ensure enough indices are generated for vmapping purposes later.
                    sequence_length=args.num_envs+1, #this is greater than the episode length, but that's fine.
                )
            )

        # Initialize the state of the replay buffer (e.g., creating the data array, setting pointers).
        # The `init` method requires a JAX PRNG key.
        # JIT-compile the initialization function as well.
        buffer_state = jax.jit(replay_buffer.init)(buffer_key)


        # === Actor Step Functions ===

        def deterministic_actor_step(training_state, env, env_state, extra_fields):
            """
            Performs a single step using the deterministic actor policy.
            Used during evaluation to assess agent performance without exploration noise.

            Args:
                training_state: The current training state (contains model parameters).
                env: The (wrapped) environment object.
                env_state: The current state of the parallel environments.
                extra_fields: Tuple of strings indicating which fields from `env_state.info`
                            should be stored in the resulting Transition's extras.

            Returns:
                A tuple containing the next environment state and the Transition data.
            """
            # Get the current batch of observations from the environment state.
            obs = env_state.obs

            # Extract the non-goal state part and the goal part from the observation.
            # Assumes obs is structured as [state_part, goal_part].
            # state shape: (num_eval_envs, obs_dim)
            state = obs[:, :args.obs_dim]
            goal = obs[:, args.obs_dim:]
            if args.full_goal_space:
                # goal = jnp.concatenate([goal, env.goal_tail], axis=-1)
                goal = jnp.concatenate([goal, env_state.info["goal_tail"]], axis=-1)


            # Encode the goal observation into its latent representation using the G-encoder.
            # We use the critic's parameters for the g_encoder.
            # g_repr shape: (num_eval_envs, rep_size)
            g_repr = g_encoder.apply(training_state.critic_state.params["g_encoder"], goal)
            
            # Get the action distribution parameters (mean, log_std) from the actor network.
            # Pass the actor parameters, state, and goal representation.
            means, _ = actor_state.apply_fn(training_state.actor_state.params, state, g_repr) # Note: actor_state.apply_fn is actor.apply

            # Select action deterministically by taking the mean and applying tanh squashing.
            # Tanh squashes the action to the range [-1, 1].
            # actions shape: (num_eval_envs, action_size)
            actions = nn.tanh( means )

            # Step the parallel environments with the chosen actions.
            nstate = env.step(env_state, actions)

            # Extract the requested extra information (e.g., 'seed') from the resulting environment state's info dictionary.
            state_extras = {x: nstate.info[x] for x in extra_fields}

            # Return the next environment state and the transition data.
            return nstate, Transition(
                observation=env_state.obs, # Observation at the start of the step.
                action=actions,            # Action taken during the step.
                extras={                   # Store extra info.
                    'state_extras': state_extras
                })

        def actor_step(training_state, env, env_state, explore_goal_rep, key, extra_fields):
            """
            Performs a single step using the stochastic actor policy with a specific exploration goal.
            Used during training data collection. The goal representation is provided externally
            based on the exploration strategy (minLSE in this script).

            Args:
                training_state: The current training state.
                env: The (wrapped) environment object.
                env_state: The current state of the parallel environments.
                explore_goal_rep: The batch of goal representations determined by the exploration strategy.
                key: JAX PRNG key for sampling noise in the action.
                extra_fields: Tuple of strings indicating which fields from `env_state.info` to store.

            Returns:
                A tuple containing the (unmodified) training state, the next environment state,
                and the Transition data.
            """
            # Extract the non-goal state part from the current observation.
            # state shape: (num_envs, obs_dim)
            state = env_state.obs[:, :args.obs_dim]

            # Get action distribution parameters from the actor, conditioned on the state
            # and the externally provided *exploration goal representation*.
            # means, log_stds shapes: (num_envs, action_size)
            means, log_stds = actor.apply(training_state.actor_state.params, state, explore_goal_rep)
            # Calculate standard deviations.
            stds = jnp.exp(log_stds)

            # Sample actions stochastically: mean + std * N(0, I).
            # Generate noise using the provided JAX PRNG key.
            # Apply tanh squashing to the sampled actions.
            # actions shape: (num_envs, action_size)
            actions = nn.tanh( means + stds * jax.random.normal(key, shape=means.shape, dtype=means.dtype) )

            # Step the parallel environments with the sampled actions.
            nstate = env.step(env_state, actions)

            # Extract the requested extra information from the resulting environment state's info.
            state_extras = {x: nstate.info[x] for x in extra_fields}
            
            # Return the training state (unchanged in this function), the next env state,
            # and the transition data using the starting observation and the taken action.
            return training_state, nstate, Transition(
                                                observation=env_state.obs,
                                                action=actions,
                                                extras={"state_extras": state_extras},
                                            )

        @jax.jit
        def get_experience(training_state, transitions, env_state, buffer_state, key):    
            """
            Collects a batch of experience (trajectories) by interacting with the environment
            using an exploration strategy based on "minLSE" goal selection from the provided transitions.
            The collected experience is then added to the replay buffer.

            Args:
                training_state: The current training state.
                transitions: A batch of previously sampled and processed (HER relabeled) transitions
                            from the replay buffer. These are used to select exploration goals.
                env_state: The current state of the parallel environments.
                buffer_state: The current state of the replay buffer.
                key: JAX PRNG key for any random operations within this function.

            Returns:
                A tuple containing the updated training_state (if modified internally, though not here),
                the new environment state, and the updated buffer state.
            """

            # --- Inner function for `jax.lax.scan` to collect one unroll_length sequence ---
            @jax.jit
            def f(carry, unused_t):
                """
                Performs a single environment step using the actor_step function with
                the pre-calculated `explore_goal_reps`.
                This function is designed to be used with `jax.lax.scan` to unroll trajectories.
                """
                # Unpack the carry state for the scan loop.
                training_state, env_state, current_key = carry
                # Split the key for the current step and the next iteration.
                current_key, next_key = jax.random.split(current_key)
                # Take an action in the environment using the actor_step function.
                # `explore_goal_reps` is captured from the outer scope of `get_experience`.
                # `extra_fields=("seed",)` ensures the 'seed' (trajectory ID) is collected.
                training_state, env_state, transition = actor_step(training_state, env, env_state, explore_goal_reps, current_key, extra_fields=("seed",))
                # Return the updated carry state and the collected transition for this step.
                # Note: `_training_state` is returned but it's not actually modified within `actor_step`.
                return (training_state, env_state, next_key), transition

            # --- Inner function for "minLSE" goal selection (vmapped) ---
            @jax.jit
            def get_worst_best_goal(rs, ra, rg):
                """
                Selects a goal representation based on the "minLSE" (minimum LogSumExp) criterion.
                This function computes distances between a set of state-action representations (from `rs`, `ra`)
                and a set of goal representations (from `rg`) in the latent space.
                It then identifies the goal that is "hardest" to reach/distinguish on average,
                by finding the goal that minimizes the LogSumExp of similarities (negative distances)
                to all state-action pairs.

                Args:
                    rs: A batch of random states (num_samples, obs_dim).
                    ra: A batch of random actions corresponding to rs (num_samples, action_size).
                    rg: A batch of random goals (num_samples, goal_dim).

                Returns:
                    The goal representation (rep_size,) from `rg` that minimizes the LSE criterion.
                """
                # Get critic parameters, stopping gradients as this is for goal selection, not critic training.
                sa_encoder_params, g_encoder_params = jax.lax.stop_gradient(training_state.critic_state.params["sa_encoder"]), jax.lax.stop_gradient(training_state.critic_state.params["g_encoder"])
                # Encode the random states and actions into latent representations.
                # random_sa_repr shape: (num_samples, rep_size)
                random_sa_repr = sa_encoder.apply(sa_encoder_params, rs, ra)
                # Encode the random goals into latent representations.
                # random_g_repr shape: (num_samples, rep_size)
                random_g_repr = g_encoder.apply(g_encoder_params, rg)


                # Calculate squared Euclidean distances between all (sa_repr, g_repr) pairs.
                # `logits` are negative distances (similarity scores).
                # random_sa_repr[:, None, :] -> (num_samples, 1, rep_size)
                # random_g_repr[None, :, :] -> (1, num_samples, rep_size)
                # Resulting logits shape: (num_samples_sa, num_samples_g)
                # Here, num_samples_sa and num_samples_g are the same (inner dimension of reshaped transitions).

                # Calculate LogSumExp across state-action pairs (axis=0) for each goal.
                # This gives a measure of how "well-covered" or "easy" each goal is by the current set of (s,a) representations.
                # A lower lse_per_goal value means the goal is generally "further" or less similar to the (s,a) pairs.
                logits = -jnp.sqrt(jnp.sum((random_sa_repr[:, None, :] - random_g_repr[None, :, :]) ** 2, axis=-1))
                # Return the goal representation corresponding to the minimum LogSumExp value.
                # This is the "hardest" or "least covered" goal according to this metric.
                return random_g_repr[ jnp.argmin( jax.nn.logsumexp(logits + 1e-6, axis=0) ) ] # axis=0 sums over sa_repr for each g_repr
            
            random_g_key, key = jax.random.split(key, 2)
            
            # --- Prepare data for minLSE goal selection ---
            # The `transitions` argument comes from `replay_buffer.sample()` and subsequent HER processing.
            # It has a flat batch dimension.
            # `transitions.extras['goal_obs']` contains future observations achieved in trajectories.
            # `transitions.extras['goal_action']` contains actions taken to reach those future observations.

            # Reshape the flat batch of 'goal_obs' (states) and 'goal_action' (actions) from HER-relabeled transitions.
            # The reshape `(args.num_envs, args.num_envs, -1)` is specific to this implementation.
            # It implies that the batch size of `transitions` is `args.num_envs * args.num_envs`.
            # The first `num_envs` dimension is for vectorizing `get_worst_best_goal` over parallel environments.
            # The second `num_envs` dimension serves as the number of samples (random_sa_repr, random_g_repr)
            # *within* each call to `get_worst_best_goal`.
            random_states = transitions.extras['goal_obs'][:, : args.obs_dim].reshape(args.num_envs, args.num_envs, -1)
            random_actions = transitions.extras['goal_action'].reshape(args.num_envs, args.num_envs, -1)
            
            # Permute and reshape the 'goal_obs' (goals) from HER-relabeled transitions.
            # This creates a set of candidate goals for the minLSE selection.
            permutation = jax.random.permutation(random_g_key, len(transitions.extras['goal_obs']))
            random_goals = transitions.extras['goal_obs'][:, args.goal_start_idx : args.goal_end_idx][permutation].reshape(args.num_envs, args.num_envs, -1) # Shuffle all goal observations

            # --- Select Exploration Goals using minLSE ---
            # Apply `get_worst_best_goal` to each slice along the first dimension (num_envs) of the reshaped data.
            # `in_axes=0` means `jax.vmap` iterates over the first axis of `random_states`, `random_actions`, and `random_goals`.
            # `explore_goal_reps` will have shape (args.num_envs, args.rep_size). Each row is an exploration goal representation
            # for one of the parallel environments.
            explore_goal_reps = jax.vmap(get_worst_best_goal, in_axes=0)(random_states, random_actions, random_goals)

            # --- Collect Trajectories ---
            # Use `jax.lax.scan` to iteratively call the inner function `f` for `args.unroll_length` steps.
            # This collects a sequence of transitions (a trajectory) for each parallel environment.
            # `initial_carry` is (training_state, env_state, key).
            # `_` in `(training_state, env_state, _)` discards the final key from scan.
            # `data` will be a Pytree of transitions, with a leading dimension of `args.unroll_length`.
            # e.g., data.observation will have shape (unroll_length, num_envs, obs_size).
            (training_state, env_state, _), data = jax.lax.scan(f, (training_state, env_state, key), (), length=args.unroll_length)

            # --- Store Experience in Buffer ---
            # Insert the collected batch of trajectories (`data`) into the replay buffer.
            buffer_state = replay_buffer.insert(buffer_state, data)

            # Return the updated states.
            return training_state, env_state, buffer_state

        def prefill_replay_buffer(training_state, env_state, buffer_state, key):
            """
            Fills the replay buffer with initial experience before training starts.
            Uses a simpler data collection strategy (actor conditioned on environment's current goal)
            as the minLSE strategy requires data in the buffer to begin with.

            Args:
                training_state: The initial training state.
                env_state: The initial state of the parallel environments.
                buffer_state: The initial (empty) state of the replay buffer.
                key: JAX PRNG key.

            Returns:
                A tuple containing the updated training_state (env_steps counter incremented),
                the new environment state, and the filled buffer state.
            """

            # --- Inner function for `jax.lax.scan` to collect data during prefill ---
            @jax.jit
            def f(carry, unused):
                """
                Performs a single environment step using the actor conditioned on the environment's
                current intrinsic goal (from `env_state.obs`).
                """
                del unused # The second argument from `jax.lax.scan` (xs) is not used here.
                # Unpack the carry state.
                training_state, env_state, key = carry
                key, current_key = jax.random.split(key)

                obs = env_state.obs
                state = obs[:, :args.obs_dim]
                goal = obs[:, args.obs_dim:]
                if args.full_goal_space:
                    # goal = jnp.concatenate([goal, env.goal_tail], axis=1) # env is not passed to this function
                    goal = jnp.concatenate([goal, env_state.info["goal_tail"]], axis=-1)

                g_repr = g_encoder.apply(training_state.critic_state.params["g_encoder"], goal)
                means, log_stds = actor.apply(training_state.actor_state.params, state, g_repr)
                stds = jnp.exp(log_stds)
                actions = nn.tanh( means + stds * jax.random.normal(current_key, shape=means.shape, dtype=means.dtype) )

                nstate = env.step(env_state, actions)
                # Collect 'seed' for trajectory identification.
                state_extras = {x: nstate.info[x] for x in ("seed",)}

                # Create the transition object.
                transition = Transition(
                    observation=env_state.obs,
                    action=actions,
                    extras={"state_extras": state_extras},
                )

                # Return updated carry and the collected transition. 
                return (training_state, nstate, key), (transition)

            # --- Collect Prefill Data ---
            # Use `jax.lax.scan` to collect a long sequence of transitions.
            # The length is `args.unroll_length * args.num_prefill_actor_steps`,
            # meaning it collects `num_prefill_actor_steps` full unrolls.
            # `data` will have shape (unroll_length * num_prefill_actor_steps, num_envs, ...).
            (training_state, env_state, _), data =  jax.lax.scan(f, (training_state, env_state, key), (), length=args.unroll_length * args.num_prefill_actor_steps)
            
            # --- Store Prefill Data in Buffer ---
            # Insert all collected prefill data into the replay buffer.
            # The buffer's insert method expects data of shape (unroll_length, num_envs, data_size)
            # or a structure that can be vmapped over. The `data` from scan is a flat sequence of transitions
            # across all unrolls and envs. The `replay_buffer.insert` will handle this structure,
            # likely by reshaping or processing it appropriately if it's designed for sequence insertion.
            # Given the buffer `insert` takes (unroll_len, num_envs, data_size), the `data` here,
            # which is (total_steps, num_envs, ...), implies the insert function is robust or the `scan`
            # is actually collecting `num_prefill_actor_steps` *sequences* of `unroll_length`.
            # Re-checking `buffer.py` `insert`: `update` has shape (unroll_len, num_envs, self._data_shape[-1]).
            buffer_state = replay_buffer.insert(buffer_state, data)
            training_state = training_state.replace(env_steps=training_state.env_steps + args.env_steps_per_actor_step * args.num_prefill_actor_steps)
            
            return training_state, env_state, buffer_state
        
        @jax.jit
        def update_actor_and_alpha(transitions, training_state, key):
            """
            Updates the actor network and the SAC entropy coefficient (alpha).

            Args:
                transitions: A batch of HER-relabeled transitions from the replay buffer.
                            Shape of tensors within transitions is typically (batch_size, ...).
                training_state: The current training state (contains actor, critic, alpha parameters and optimizers).
                key: JAX PRNG key for sampling actions during the actor loss calculation.

            Returns:
                A tuple containing the updated training_state and a dictionary of metrics.
            """

        # Define the loss function for the actor
            def actor_loss(actor_params, critic_params, log_alpha, transitions, key):
                """
                Computes the loss for the actor.
                The actor aims to maximize the Q-value (approximated by similarity to goal) 
                plus an entropy bonus for its actions.
                Loss = E[-Q(s,a,g) + alpha * log pi(a|s,g)]
                """
                # Extract current state from the transitions extras
                state = transitions.extras["state"]
                goal = transitions.extras['goal_obs'][:, args.goal_start_idx : args.goal_end_idx]
                sa_encoder_params, g_encoder_params = jax.lax.stop_gradient(critic_params["sa_encoder"]), jax.lax.stop_gradient(critic_params["g_encoder"])
                
                g_repr = g_encoder.apply(g_encoder_params, goal)

                means, log_stds = actor.apply(actor_params, state, g_repr)
                stds = jnp.exp(log_stds)
                x_ts = means + stds * jax.random.normal(key, shape=means.shape, dtype=means.dtype)
                action = nn.tanh(x_ts)
                log_prob = jax.scipy.stats.norm.logpdf(x_ts, loc=means, scale=stds)
                log_prob -= jnp.log((1 - jnp.square(action)) + 1e-6)
                log_prob = log_prob.sum(-1)           # shape = B

                sa_repr = sa_encoder.apply(sa_encoder_params, state, action)
                qf_pi = -jnp.sqrt(jnp.sum((sa_repr - g_repr) ** 2, axis=-1))      # shape = B

                actor_loss = jnp.mean( jnp.exp(log_alpha) * log_prob - (qf_pi) )

                return actor_loss, log_prob

            def alpha_loss(alpha_params, log_prob):
                alpha = jnp.exp(alpha_params["log_alpha"])
                alpha_loss = alpha * jnp.mean(jax.lax.stop_gradient(-log_prob - target_entropy))
                return jnp.mean(alpha_loss)
            
            (actorloss, log_prob), actor_grad = jax.value_and_grad(actor_loss, has_aux=True)(training_state.actor_state.params, training_state.critic_state.params, training_state.alpha_state.params['log_alpha'], transitions, key)
            new_actor_state = training_state.actor_state.apply_gradients(grads=actor_grad)

            alphaloss, alpha_grad = jax.value_and_grad(alpha_loss)(training_state.alpha_state.params, log_prob)
            new_alpha_state = training_state.alpha_state.apply_gradients(grads=alpha_grad)

            training_state = training_state.replace(actor_state=new_actor_state, alpha_state=new_alpha_state)

            metrics = {
                "sample_entropy": -log_prob,
                "actor_loss": actorloss,
                "alpha_aloss": alphaloss,   
                "log_alpha": training_state.alpha_state.params["log_alpha"],
            }

            return training_state, metrics
        
        @jax.jit
        def update_critic(transitions, training_state, key):
            def critic_loss(critic_params, transitions, key):
                sa_encoder_params, g_encoder_params = critic_params["sa_encoder"], critic_params["g_encoder"]
                
                state = transitions.extras["state"]
                goal = transitions.extras['goal_obs'][:, args.goal_start_idx : args.goal_end_idx]
                action = transitions.action
                
                sa_repr = sa_encoder.apply(sa_encoder_params, state, action)
                g_repr = g_encoder.apply(g_encoder_params, goal)
                
                # # InfoNCE
                # logits = -jnp.sqrt(jnp.sum((sa_repr[:, None, :] - g_repr[None, :, :]) ** 2, axis=-1)) #shape = BxB
                # critic_loss = -jnp.mean( jnp.diag(logits) - jax.nn.logsumexp(logits, axis=1) )
                
                # backward InfoNCE
                logits = -jnp.sqrt(jnp.sum((sa_repr[:, None, :] - g_repr[None, :, :]) ** 2, axis=-1)) #shape = BxB
                critic_loss = -jnp.mean( jnp.diag(logits) - jax.nn.logsumexp(logits, axis=0) )

                # logsumexp regularisation
                logsumexp = jax.nn.logsumexp(logits + 1e-6, axis=1)
                critic_loss += args.logsumexp_penalty_coeff * jnp.mean(logsumexp**2)

                I = jnp.eye(logits.shape[0])
                correct = jnp.argmax(logits, axis=1) == jnp.argmax(I, axis=1)
                logits_pos = jnp.sum(logits * I) / jnp.sum(I)
                logits_neg = jnp.sum(logits * (1 - I)) / jnp.sum(1 - I)

                return critic_loss, (logsumexp, correct, logits_pos, logits_neg)
                
            (loss, (logsumexp, correct, logits_pos, logits_neg)), grad = jax.value_and_grad(critic_loss, has_aux=True)(training_state.critic_state.params, transitions, key)
            new_critic_state = training_state.critic_state.apply_gradients(grads=grad)
            training_state = training_state.replace(critic_state = new_critic_state)

            metrics = {
                "categorical_accuracy": jnp.mean(correct),
                "logits_pos": logits_pos,
                "logits_neg": logits_neg,
                "logsumexp": logsumexp.mean(),
                "critic_loss": loss,
            }

            return training_state, metrics
        
        @jax.jit
        def sgd_step(carry, transitions):
            training_state, key = carry
            key, critic_key, actor_key = jax.random.split(key, 3)

            training_state, actor_metrics = update_actor_and_alpha(transitions, training_state, actor_key)

            training_state, critic_metrics = update_critic(transitions, training_state, critic_key)

            training_state = training_state.replace(gradient_steps = training_state.gradient_steps + 1)

            metrics = {}
            metrics.update(actor_metrics)
            metrics.update(critic_metrics)
            
            return (training_state, key,), metrics

        @jax.jit
        def training_step(training_state, env_state, buffer_state, key):
            experience_key1, experience_key2, sampling_key, training_key = jax.random.split(key, 4)
            
            # sample actor-step worth of transitions
            buffer_state, transitions = replay_buffer.sample(buffer_state)

            # process transitions for training
            batch_keys = jax.random.split(sampling_key, transitions.observation.shape[0])
            transitions = jax.vmap(TrajectoryUniformSamplingQueue.flatten_crl_fn, in_axes=(None, 0, 0))(
                (args.gamma, args.obs_dim, args.goal_start_idx, args.goal_end_idx), transitions, batch_keys
            )
            
            transitions = jax.tree_util.tree_map(
                lambda x: jnp.reshape(x, (-1,) + x.shape[2:], order="F"),
                transitions,
            )

            permutation = jax.random.permutation(experience_key2, len(transitions.action))
            transitions = jax.tree_util.tree_map(lambda x: x[permutation], transitions)

            # update buffer
            training_state, env_state, buffer_state = get_experience(
                training_state,
                transitions,
                env_state,
                buffer_state,
                experience_key1,
            )
            training_state = training_state.replace(
                env_steps=training_state.env_steps + args.env_steps_per_actor_step,
            )

            transitions = jax.tree_util.tree_map(
                lambda x: jnp.reshape(x, (-1, args.batch_size) + x.shape[1:]),
                transitions,
            )
            
            # take actor-step worth of training-step
            (training_state, _,), metrics = jax.lax.scan(sgd_step, (training_state, training_key), transitions)
            
            return (training_state, env_state, buffer_state,), metrics

        @jax.jit
        def training_epoch(
            training_state,
            env_state,
            buffer_state,
            key,
        ):  
            @jax.jit
            def f(carry, unused_t):
                ts, es, bs, k = carry
                k, train_key = jax.random.split(k, 2)
                (ts, es, bs,), metrics = training_step(ts, es, bs, train_key)
                return (ts, es, bs, k), metrics

            (training_state, env_state, buffer_state, key), metrics = jax.lax.scan(f, (training_state, env_state, buffer_state, key), (), length=args.num_training_steps_per_epoch)
            
            metrics["buffer_current_size"] = replay_buffer.size(buffer_state)
            return training_state, env_state, buffer_state, metrics
        
        '''Setting up evaluator'''
        evaluator = CrlEvaluator(
            deterministic_actor_step,
            env,
            num_eval_envs=args.num_eval_envs,
            episode_length=args.episode_length,
            key=eval_env_key,
        )

        print('prefilling replay buffer....')
        key, prefill_key = jax.random.split(key, 2)
        training_state, env_state, buffer_state = prefill_replay_buffer(
            training_state, env_state, buffer_state, prefill_key
        )

        training_walltime = 0
        print('starting training....')
        for ne in range(args.num_epochs):
            
            t = time.time()

            key, epoch_key = jax.random.split(key)
            training_state, env_state, buffer_state, metrics = training_epoch(training_state, env_state, buffer_state, epoch_key)
            
            metrics = jax.tree_util.tree_map(jnp.mean, metrics)
            metrics = jax.tree_util.tree_map(lambda x: x.block_until_ready(), metrics)

            epoch_training_time = time.time() - t
            training_walltime += epoch_training_time

            sps = (args.env_steps_per_actor_step * args.num_training_steps_per_epoch) / epoch_training_time
            metrics = {
                "training/sps": sps,
                "training/walltime": training_walltime,
                "training/envsteps": training_state.env_steps.item(),
                **{f"training/{name}": value for name, value in metrics.items()},
            }

            metrics = evaluator.run_evaluation(training_state, metrics)

            print(metrics)


            if args.checkpoint:
                # Save current policy and critic params.
                params = (training_state.alpha_state.params, training_state.actor_state.params, training_state.critic_state.params)
                path = f"{save_path}/step_{int(training_state.env_steps)}.pkl"
                save_params(path, params)
            
            if args.track:
                wandb.log(metrics, step=ne)

                if args.wandb_mode == 'offline':
                    trigger_sync()
        
        if args.checkpoint:
            # Save current policy and critic params.
            params = (training_state.alpha_state.params, training_state.actor_state.params, training_state.critic_state.params)
            path = f"{save_path}/final.pkl"
            save_params(path, params)
        
        if args.track:
            wandb.finish()

