import jax
import time
import numpy as np

from flax import struct
from typing import Dict
from envs.wrappers import EvalWrapper, EvalMetrics

# Dataclass likely used later in the evaluator to store metrics from different
# evaluation scenarios (e.g., 'easy' vs 'hard' goals).
@struct.dataclass
class HierarchicalEvalMetrics:
	metrics: Dict[str, EvalMetrics]

# Function definition: generates a sequence of environment interactions (an unroll)
def generate_unroll(
	actor_step, 	# A function that performs one step of agent interaction in the env.
					# This function takes (training_state, env, current_env_state)
					# and returns (next_env_state, transition_data).
					# During evaluation, this should use a deterministic policy. (to be confirmed)

	training_state, # Contains the learned parameters (e.g., actor network weights)
                    # needed by the actor_step function. 
	env, 			# The environment instance (likely wrapped, e.g., with EvalWrapper).
	env_state, 		# The initial state of the environment(s) to start the unroll from.
	unroll_length, 	# The number of steps to simulate.
	extra_fields=()	# Optional: tuple of keys specifying extra info to extract from
                    # env_state.info and include in the returned transition data.
	):
	"""Collect trajectories of given unroll_length."""

    # Define a function 'f' that performs a single step of the simulation.
    # This function will be repeatedly called by jax.lax.scan.
	@jax.jit
	def f(
		carry,	# The 'carry' state passed from one iteration to the next.
                # In this case, it's the current state of the environment(s).
		unused_t	# Placeholder for per-step input data from `scan`. Since we're just
                        # running for a fixed number of steps and don't have external
                        # inputs per step, this is unused (indicated by the name).
		):
		state = carry
		# Call the provided actor_step function:
        # - It uses the learned policy parameters (training_state)
        # - Interacts with the environment (env) starting from the current state (state)
        # - Optionally collects extra data specified by extra_fields
        # It returns:
        # - nstate: The environment state after one step.
        # - transition: Data collected during this step (e.g., obs, action, reward, next_obs).
		nstate, transition = actor_step(training_state, env, state, extra_fields=extra_fields)
		# Return the next state (nstate) as the new carry for the next iteration,
        # and the collected transition data as the output for this iteration.
		return nstate, transition

	# scan returns:
    # - final_state: The carry state after the last iteration (the env state after unroll_length steps).
    # - data: A pytree containing the outputs (transitions) collected at each step.
    #         If transition has shape (num_envs, ...), data will have shape (unroll_length, num_envs, ...).
	final_state, data = jax.lax.scan(f, env_state, (), length=unroll_length)
	
	# Return the final state of the environment and the collected trajectory data.
	return final_state, data

# The main class responsible for evaluating the performance of the trained agent.
class CrlEvaluator():

	# Initialize the evaluator.
	def __init__(
		self,
		actor_step,	# Function defining how the agent takes a step (uses deterministic policy).
		eval_env,	# The base environment instance used for evaluation.
		num_eval_envs,	# Number of parallel environments to run evaluation on.
		episode_length,	# Maximum number of steps per evaluation episode.
		key
		):
		self._key = key
		
		# Initialize a counter for the total wall-clock time spent on evaluation runs.
		self._eval_walltime = 0.
		
		# Wrap the provided evaluation environment with the EvalWrapper.
		# This wrapper adds logic for tracking episode progress and metrics automatically.
		eval_env = EvalWrapper(eval_env)
		
		# JIT-compile the reset and step functions of the wrapped environment for performance.
		# This is crucial as evaluation involves many steps.
		eval_env.reset = jax.jit(eval_env.reset)
		eval_env.step = jax.jit(eval_env.step)

		# --- Check if the environment supports hierarchical evaluation (different goal sets) ---
		# The `ant_maze.py` environment, for example, defines `eval_possible_goals`.
		if hasattr(eval_env, 'eval_possible_goals'):
			eval_env.reset_with_specific_target_settings = jax.jit(eval_env.reset_with_specific_target_settings)
			
			# Store the defined evaluation goal sets (e.g., {'easy': goals_easy, 'hard': goals_hard}).
			self.eval_possible_goals = eval_env.eval_possible_goals

			# --- Define the function that runs evaluation across all defined goal sets ---
			def generate_eval_unroll(training_state, key):
				# Dictionary to store metrics, keyed by the goal set name (e.g., 'easy', 'hard').
				metrics = {}

				# Iterate through each defined evaluation goal set.
				# dict_key: name of the goal set (e.g., 'easy')
				# dict_value: the actual goal locations/parameters for that set
				for dict_key, dict_value in self.eval_possible_goals.eval_goals.items():
					# Split the key for this specific evaluation run.
					# eval_key is used for resetting envs in this iteration.
					# key is passed to the next iteration of the loop, ensuring each
					# goal set gets a different stream of randomness if needed later,
					# although here only eval_key is immediately used.
					eval_key, key = jax.random.split(key, 2)
					# Generate separate reset keys for each parallel evaluation environment.
					reset_keys = jax.random.split(eval_key, num_eval_envs)
					# Reset the environments using the specific goal set for this scenario.
					eval_first_state = eval_env.reset_with_specific_target_settings(reset_keys, dict_value)
					# Run the simulation using the utility function.
					# We run for one full 'episode_length'.
					# We only need the final state (`[0]`) which contains the accumulated metrics in its `info`.
					metrics[dict_key] = generate_unroll(
						actor_step,
						training_state,
						eval_env,
						eval_first_state,
						unroll_length=episode_length)[0].info["eval_metrics"] # Extract metrics collected by EvalWrapper

				# Return all collected metrics, structured by goal set name.
				return HierarchicalEvalMetrics(metrics=metrics)

			# JIT-compile the entire evaluation function (including the loop over goal sets).
			self._generate_eval_unroll = jax.jit(generate_eval_unroll)
			# Calculate the total number of environment steps performed in one call
			# to _generate_eval_unroll (considers parallel envs and multiple goal sets).
			self._steps_per_unroll = episode_length * num_eval_envs * len(self.eval_possible_goals.eval_goals.keys())

		# --- Else: Standard evaluation (no specific goal sets defined) ---
		else:
			# --- Define the function that runs a standard evaluation ---
			def generate_eval_unroll(training_state, key):
				# Generate separate reset keys for each parallel evaluation environment.
				reset_keys = jax.random.split(key, num_eval_envs)
				# Reset the environments using the standard reset method (random goals usually).
				eval_first_state = eval_env.reset(reset_keys)
				# Run the simulation using the utility function.
				# Return the final state which contains metrics in its `info` field.
				return generate_unroll(
					actor_step,
					training_state,
					eval_env,
					eval_first_state,
					unroll_length=episode_length)[0] # Return the final State dataclass (is it a dataclass?)

			self._generate_eval_unroll = jax.jit(generate_eval_unroll)
			# Calculate the total number of environment steps performed in one call
			# to _generate_eval_unroll (considers parallel envs only).
			self._steps_per_unroll = episode_length * num_eval_envs

	# Method to execute one full evaluation epoch.
	def run_evaluation(
		self,
		training_state,		# The current state of the agent's learned parameters.
		training_metrics,	# Metrics collected during the last training phase (to be merged).
		aggregate_episodes = True	# Flag: if True, average metrics across parallel envs.
		                        	# If False, return raw metrics per environment.
		):
		"""Run one epoch of evaluation."""
		# Get a unique key for this specific evaluation run from the evaluator's key.
		self._key, unroll_key = jax.random.split(self._key)
		# Record the start time for timing the evaluation run.
		t = time.time()

		# --- Check again if hierarchical evaluation is configured ---
		if hasattr(self, 'eval_possible_goals'):
			# Call the JIT-compiled function to run simulations for all goal sets.
			h_metrics = self._generate_eval_unroll(training_state, unroll_key)
			# Ensure all JAX computations are finished before proceeding.
			# This is necessary for accurate timing and to access the results safely.
			# We map this function over the potentially nested structure of h_metrics. (need to understand it better)
			h_metrics = jax.tree_util.tree_map(lambda x: x.block_until_ready(), h_metrics)
			# Calculate the wall-clock time taken for this evaluation epoch.
			epoch_eval_time = time.time() - t
			
			# Initialize dictionary to store the final processed metrics.
			metrics = {}
			# Iterate through the metrics collected for each goal set (e.g., 'easy', 'hard').
			for key_eval_metrics, eval_metrics in h_metrics.metrics.items(): # key_eval_metrics is 'easy', 'hard', etc.
				
				# Define how to aggregate metrics across the parallel environments.
				# Currently, only mean aggregation is used. Could add std, min, max etc.
				aggregating_fns = [(np.mean, ""),] # List of (function, suffix) pairs
				for (fn, suffix) in aggregating_fns:
					# Update the metrics dictionary with aggregated values.
					metrics.update(
						{
							# Construct the metric name, e.g., "eval/easy/episode_reward"
							f"eval/{key_eval_metrics}/episode_{name}{suffix}": (
								# Apply aggregation function (e.g., np.mean) if requested.
								fn(eval_metrics.episode_metrics[name]) if aggregate_episodes
								# Otherwise, keep the raw data (likely an array of metrics per env).
								else eval_metrics.episode_metrics[name]
							)
							# Iterate through a predefined list of possible metric names.
							# Only include metrics that were actually collected and exist in eval_metrics.episode_metrics.
							for name in ['reward', 'success', 'success_easy', 'success_hard', 'success_stand', 'dist', 'distance_from_origin'] if name in eval_metrics.episode_metrics.keys()
						}
					)

				# Calculate a specific metric: the proportion of environments where success was achieved
				# at least once during the episode (i.e., success > 0.0).
				# We check in how many env there was at least one step where there was success
				# NOTE that episode_metrics are already accumulated over all previous steps (what EvalWrapper does).
				if "success" in eval_metrics.episode_metrics:
					metrics[f"eval/{key_eval_metrics}/episode_success_any"] = np.mean(
						eval_metrics.episode_metrics["success"] > 0.0
					)

			# Calculate average episode length. Note: This uses the 'eval_metrics' from the *last*
            # iteration of the loop above. If multiple goal sets exist, this reports the average
            # length for only the last set ('hard' in the typical 'easy', 'hard' case).
			metrics[f"eval/{key_eval_metrics}/avg_episode_length"] = np.mean(eval_metrics.episode_steps)
			
			# Add timing and performance metrics for the evaluation epoch.
			metrics["eval/epoch_eval_time"] = epoch_eval_time
			metrics["eval/sps"] = self._steps_per_unroll / epoch_eval_time # Steps Per Second
			# Update and store the cumulative evaluation wall time.
			self._eval_walltime = self._eval_walltime + epoch_eval_time
			
			# Merge the evaluation metrics with the training metrics passed into the function.
			metrics = {"eval/walltime": self._eval_walltime, **training_metrics, **metrics}

		# --- Else: Standard Evaluation Execution ---
		else:
			# Call the JIT-compiled function for standard evaluation. Returns the final state.
			eval_state = self._generate_eval_unroll(training_state, unroll_key)
			# Extract the EvalMetrics object collected by the EvalWrapper.
			eval_metrics = eval_state.info["eval_metrics"]
			# Ensure JAX computations are finished. Waiting on `active_episodes`
			# (likely part of EvalMetrics structure) is a way to achieve this.
			# NOTE: NEED TO UNDERSTAND THIS BETTER
			eval_metrics.active_episodes.block_until_ready()
			# Calculate the wall-clock time taken for this evaluation epoch.
			epoch_eval_time = time.time() - t
			# Initialize dictionary for processed metrics.
			metrics = {}
			# Define aggregation functions (same as above).
			aggregating_fns = [(np.mean, ""),]

			# Loop through aggregation functions (currently just mean).
			for (fn, suffix) in aggregating_fns:
				# Update the metrics dictionary with aggregated values.
				metrics.update(
					{
					# Construct metric name, e.g., "eval/episode_reward" (no goal set key needed).
					f"eval/episode_{name}{suffix}": (
						fn(eval_metrics.episode_metrics[name]) if aggregate_episodes else eval_metrics.episode_metrics[name]
					)
					# Iterate through possible metric names found in the collected data.
					for name in ['reward', 'success', 'success_easy', 'success_hard', 'success_stand', 'dist', 'distance_from_origin'] if name in eval_metrics.episode_metrics.keys()
					}
				)

			# Calculate the proportion of environments with at least one success in the episode.
			if "success" in eval_metrics.episode_metrics:
				metrics["eval/episode_success_any"] = np.mean(
					eval_metrics.episode_metrics["success"] > 0.0
				)

			# Calculate the average episode length across all parallel environments.
			metrics["eval/avg_episode_length"] = np.mean(eval_metrics.episode_steps)
			# Add timing and performance metrics.
			metrics["eval/epoch_eval_time"] = epoch_eval_time
			metrics["eval/sps"] = self._steps_per_unroll / epoch_eval_time # Steps Per Second
			# Update and store the cumulative evaluation wall time.
			self._eval_walltime = self._eval_walltime + epoch_eval_time
			
			# Merge evaluation metrics with incoming training metrics.
			metrics = {"eval/walltime": self._eval_walltime, **training_metrics, **metrics}
		
		return metrics