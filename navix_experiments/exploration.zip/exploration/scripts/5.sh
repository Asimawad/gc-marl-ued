#!/bin/bash

#SBATCH --job-name=jax-gcrl
#SBATCH --time=14:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --gres=gpu:1
#SBATCH --constraint=gpu80
#SBATCH --array=1-9
#SBATCH --mail-type=end
#SBATCH --mail-user=rg9360@princeton.edu

seed=('1' '2' '3')

env=('ant' 'humanoid' 'arm_reach')

s=${seed[$(((SLURM_ARRAY_TASK_ID-1) % 3))]}
echo ${s}

e=${env[$(((SLURM_ARRAY_TASK_ID-1) / 3))]}
echo ${e}

d='/scratch/gpfs/rg9360/exploration-online'

module purge
module load anaconda3/2024.2
conda activate jax-gcrl

cd /home/rg9360/exploration

python train_crl_latent_actor_online_kde.py --wandb_group random_mingoals --num_envs 4096 --total_env_steps 5000000000 --batch_size 1024 --env-id ${e} --seed ${s} --track --wandb-dir ${d} --wandb-mode offline --checkpoint