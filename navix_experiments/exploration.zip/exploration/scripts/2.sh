#!/bin/bash

#SBATCH --job-name=jax-gcrl
#SBATCH --time=10:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --gres=gpu:1
#SBATCH --constraint=gpu80
#SBATCH --array=1-15
#SBATCH --mail-type=end
#SBATCH --mail-user=rg9360@princeton.edu

seed=('1' '2' '3')

env=('pusher' 'humanoid' 'ant_ball' 'humanoid_standup' 'ant_hardest_maze')

s=${seed[$(((SLURM_ARRAY_TASK_ID-1) % 3))]}
echo ${s}

e=${env[$(((SLURM_ARRAY_TASK_ID-1) / 3))]}
echo ${e}

d='/scratch/gpfs/rg9360/exploration'

module purge
module load anaconda3/2024.2
conda activate jax-gcrl

cd /home/rg9360/exploration

python train_goal_kde.py --wandb_group baseline_goal_kde --total_env_steps 300000000 --batch_size 1024 --env-id ${e} --seed ${s} --track --wandb-dir ${d} --wandb-mode offline --checkpoint