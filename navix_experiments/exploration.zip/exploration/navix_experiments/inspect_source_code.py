import navix
import inspect
import os

# Get the file path of the navix.environments.environment module
# (since Environment class is defined there)
try:
    environment_module = navix.environments.environment
    file_path = inspect.getfile(environment_module)
    print(f"The navix.environments.environment module is imported from: {file_path}")

    # You can then open and print the contents if you wish (might be long)
    # with open(file_path, 'r') as f:
    #     print("\n--- Source Code of Environment Class ---")
    #     # This will print the whole file, you'd need to manually find the class
    #     # print(f.read())

    # More specifically, for the Environment class itself:
    environment_class = navix.environments.Environment
    class_file_path = inspect.getfile(environment_class)
    print(f"The navix.environments.Environment class is defined in: {class_file_path}")

    # To get the source code of just the class (if available)
    try:
        source_code = inspect.getsource(environment_class)
        print("\n--- Source Code of navix.environments.Environment ---")
        print(source_code)
        # Now you can visually inspect the `create` method for the max_steps logic
    except TypeError:
        print(f"Could not get source code directly for {environment_class}. It might be a C extension or built-in.")
    except OSError:
        print(f"Could not find the source file for {environment_class} at {class_file_path}.")


    # You can also check the version of the Navix library if it's set
    if hasattr(navix, '__version__'):
        print(f"\nInstalled Navix version: {navix.__version__}")
    else:
        print("\nNavix version attribute (__version__) not found.")

except AttributeError:
    print("Could not find navix.environments.environment or navix.environments.Environment.")
except ImportError:
    print("Navix library not found or import error.")