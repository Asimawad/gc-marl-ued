import jax
import flax
import functools
import jax.numpy as jnp

# Import utility from JAX for flattening and unflattening PyTrees.
# This is essential for storing complex data structures (like the Transition NamedTuple)
# efficiently into a single JAX array.
from jax import flatten_util
# Import the PRNGKey type hint from brax for clarity. (need to be understood further)
from brax.training.types import PRNGKey


# Defines the state of the replay buffer using a Flax struct.
# Flax structs are dataclasses compatible with JAX transformations (jit, vmap, etc.)
# and are generally immutable.
@flax.struct.dataclass
class ReplayBufferState:
  """Contains the state of the replay buffer.

  Attributes:
    data: The main storage array for replay data. Expected shape is
      (max_replay_size, num_envs, flattened_data_size).
    insert_position: A scalar int32 JAX array indicating the index in the first
      dimension (time) where the *next* piece of data should be inserted.
      Acts as a pointer for insertion.
    sample_position: A scalar int32 JAX array indicating the index of the
      *oldest valid* data point in the buffer. Used to define the range of
      valid data for sampling: [sample_position, insert_position).
    key: A JAX PRNGKey used for subsequent sampling operations.
  """
  data: jnp.ndarray
  insert_position: jnp.ndarray
  sample_position: jnp.ndarray
  key: PRNGKey


class TrajectoryUniformSamplingQueue():
    """A replay buffer that stores transitions and samples sequences uniformly.

    Stores transitions flattened into 1D arrays for potentially better performance
    with JAX operations. Assumes data comes from parallel environments.
    """
    def __init__(
        self,
        max_replay_size: int,
        dummy_data_sample,
        sample_batch_size: int,
        num_envs: int,
        sequence_length: int,
    ):
        """Initializes the buffer configuration.

        Args:
            max_replay_size: The total capacity of the buffer along the time dimension.
            dummy_data_sample: An instance of the data structure that will be stored
              (e.g., a Transition NamedTuple). Used to determine the flattened data
              size and the unflattening function.
            sample_batch_size: The size of batches expected by the learner during training.
            num_envs: The number of parallel environments contributing data.
            sequence_length: The fixed length of subsequences to sample from the buffer.
        """

        # --- Flattening/Unflattening Setup ---
        # What inside the double vmaps is a function that flattens a single data sample (e.g., one Transition) into a 1D array.
        # `flatten_util.ravel_pytree` returns the flattened array and an unflatten function.
        # We take the 0th element which is the flattened array.
        # We expect data to arrive in batches, typically (time_steps, num_envs, ...original_structure...).
        # We need to flatten each element in this batch. We use vmap twice:
        # 1. Vmap over the `num_envs` dimension.
        # 2. Vmap over the `time_steps` dimension.
        # This creates a function that takes a batch and returns a batch of flattened arrays.
        self._flatten_fn = jax.vmap(jax.vmap(lambda x: flatten_util.ravel_pytree(x)[0]))

        # Use the dummy sample to get an example flattened array and the unflatten function.
        dummy_flatten, self._unflatten_fn = flatten_util.ravel_pytree(dummy_data_sample)
    
        # Similar to flattening, create a doubly-vmapped version of the unflatten function
        # to reconstruct the original data structure from batches of flattened arrays.
        self._unflatten_fn = jax.vmap(jax.vmap(self._unflatten_fn))

        # The size of the flattened representation of a single data sample.
        data_size = len(dummy_flatten)


        # --- Buffer Configuration Storage ---
        # Define the shape of the main data storage array.
        self._data_shape = (max_replay_size, num_envs, data_size)
        # Store the data type inferred from the dummy sample.
        self._data_dtype = dummy_flatten.dtype
        # Store the configuration parameters.
        self._sample_batch_size = sample_batch_size # Note: Used downstream, not directly in this class's sample method.
        self.num_envs = num_envs
        self.sequence_length = sequence_length # Length of sequences returned by sample()


    def init(self, key):
        """Initializes the state of the replay buffer.

        Args:
            key: A JAX PRNGKey for initializing the buffer's random state.

        Returns:
            An initial ReplayBufferState with empty data and reset positions.
        """
        # Create the initial ReplayBufferState:
        return ReplayBufferState(
            # Initialize the data buffer with zeros.
            data=jnp.zeros(self._data_shape, self._data_dtype),
            # Start sampling from the beginning (index 0).
            sample_position=jnp.zeros((), jnp.int32),
            # Start inserting data at the beginning (index 0).
            insert_position=jnp.zeros((), jnp.int32),
            # Store the initial random key.
            key=key,
        )


    def insert(self, buffer_state, samples):
        """Inserts a batch of data samples into the buffer.

        Handles circular buffer logic by rolling old data if necessary.

        Args:
            buffer_state: The current state of the replay buffer.
            samples: The new data to insert, expected to have a structure matching
                     dummy_data_sample, typically with leading dimensions
                     (unroll_length, num_envs).

        Returns:
            A new ReplayBufferState with the inserted data and updated positions.
        """
        # --- Input Validation ---
        if buffer_state.data.shape != self._data_shape:
            raise ValueError(
                f"buffer_state.data.shape ({buffer_state.data.shape}) "
                f"doesn't match the expected value ({self._data_shape})"
            )

        # --- Data Preparation ---
        # Flatten the incoming samples to match the buffer's storage format.
        # samples shape: (unroll_len, num_envs, ...structure...)
        # update shape: (unroll_len, num_envs, flattened_data_size)
        update = self._flatten_fn(samples)
        data = buffer_state.data # shape = (max_replay_size, num_envs, data_size)


        # --- Circular Buffer Logic: Rolling ---
        # Check if inserting the new data `update` exceeds the buffer capacity
        # starting from the current `insert_position`.
        position = buffer_state.insert_position
        # Calculate how much space is *missing* at the end of the buffer.
        # Example: size=100, pos=90, update_len=15. Space left = 100-90=10.
        #          Missing = 10 - 15 = -5. We need to roll by -5.
        # Example: size=100, pos=70, update_len=15. Space left = 100-70=30.
        #          Missing = 30 - 15 = 15. We have enough space. Missing >= 0.
        # `roll` determines how many steps to shift the buffer upwards (discarding oldest).
        # It's negative if rolling is needed, 0 otherwise.
        roll = jnp.minimum(0, len(data) - position - len(update)) # roll will be <= 0

        # Conditionally roll the buffer data upwards along the time axis (axis=0)
        # only if `roll` is negative (i.e., space was lacking).
        data = jax.lax.cond(roll, lambda: jnp.roll(data, roll, axis=0), lambda: data)
        # Adjust the insertion position based on the roll. If roll was -5,
        # the effective starting index moves up by 5 relative to original indices.
        position = position + roll

        # --- Data Insertion ---
        # Insert the flattened `update` data into the (potentially rolled) `data` array.
        # Starts inserting at the calculated `position` along the time dimension (axis=0).
        # This overwrites old data or data that wrapped around from the roll.
        data = jax.lax.dynamic_update_slice_in_dim(data, update, position, axis=0)

        # --- Update Buffer Pointers ---
        # Calculate the next insertion position.
        # `(position + unroll_len)` is where the current insertion ended.
        # The modulo `% (max_buffer_size + 1)` handles wrapping.
        # It allows `position` to reach `max_buffer_size` (indicating full up to the end)
        # instead of wrapping immediately to 0 when `position + unroll_len == max_buffer_size`.
        # If `position + unroll_len > max_buffer_size` (shouldn't happen with roll logic, but robust),
        # it wraps appropriately.
        position = (position + len(update)) % (len(data) + 1)    # so whenever roll happens, position becomes len(data), else it is increased by len(update), what is the use of doing % (len(data) + 1)?? 

        # Update the position of the oldest valid sample.
        # If a roll occurred (roll < 0), the oldest samples were discarded,
        # so `sample_position` needs to be shifted forward by the same amount.
        # `buffer_state.sample_position + roll` increases sample_position because roll is negative.
        # `jnp.maximum(0, ...)` prevents it from becoming negative.
        # If roll == 0, sample_position remains unchanged.
        sample_position = jnp.maximum(0, buffer_state.sample_position + roll) # what is the use of this line? sample_position always remains 0 as roll can never be positive


        # --- Return New State ---
        # Create and return a new buffer state with updated data and pointers.
        # Note: Flax dataclasses are immutable, so `replace` creates a new instance.
        return buffer_state.replace(
            data=data,
            insert_position=position,
            sample_position=sample_position,
            # key remains the same as insertion is deterministic
        )


    def sample(self, buffer_state):
        """Samples a batch of trajectory sequences from the buffer.

        Randomly selects starting points in time for each environment within the
        valid data range and extracts sequences of `self.sequence_length`.

        Args:
            buffer_state: The current state of the replay buffer.

        Returns:
            A tuple containing:
                - The new ReplayBufferState (with an updated random key).
                - The sampled batch of transitions, unflattened to their original
                  structure, typically with shape (num_envs, sequence_length)
                  where each element is a structured transition (e.g., NamedTuple).
        """
        # --- Input Validation ---
        if buffer_state.data.shape != self._data_shape:
            raise ValueError(
                f"Data shape expected by the replay buffer ({self._data_shape}) does "
                f"not match the shape of the buffer state ({buffer_state.data.shape})"
            )

        # --- Setup ---
        # Split the key for current sampling and for the next state.
        key, sample_key, shuffle_key = jax.random.split(buffer_state.key, 3) # shuffle_key seems unused?
        
        # Determine how many environments worth of sequences to sample.
        # Currently set to sample one sequence from each environment.
        # Could be adjusted (e.g., sample more sequences from fewer envs).
        # Note: this is the number of envs to sample but it can be modified if there is OOM
        shape = self.num_envs

        # --- Environment Index Sampling ---
        # Get indices for the environments from which to sample sequences.
        # Here, since num_sequences_to_sample == self.num_envs and replace=False,
        # this effectively just creates a permutation of all environment indices [0, ..., num_envs-1].
        # If num_sequences_to_sample < self.num_envs, it would select a random subset.
        envs_idxs = jax.random.choice(sample_key, jnp.arange(self.num_envs), shape=(shape,), replace=False) # I think shuffle key should be used instead?

        # --- Time Index Sampling Helper ---
        # This function generates the matrix of time indices to sample.
        @functools.partial(jax.jit, static_argnames=("rows", "cols")) # Jit compile, rows/cols are static (NEED TO UNDERSTAND THIS)
        def create_matrix(rows, cols, min_val, max_val, rng_key):
            """Creates a matrix of sequential indices for sampling.

            Args:
                rows: Number of sequences (environments) to sample for.
                cols: Length of each sequence (self.sequence_length).
                min_val: Minimum valid starting time index (buffer_state.sample_position).
                max_val: Maximum valid starting time index (buffer_state.insert_position - self.sequence_length).
                rng_key: JAX PRNGKey.

            Returns:
                A (rows, cols) matrix where matrix[i, j] is the time index for the
                j-th step of the i-th sequence.
            """
            rng_key, subkey = jax.random.split(rng_key)
            # Sample random start times for each sequence within the valid range.
            # Shape: (rows,)
            start_values = jax.random.randint(subkey, shape=(rows,), minval=min_val, maxval=max_val)
            # Sequence offsets: [0, 1, ..., cols-1]. Shape: (cols,)
            row_indices = jnp.arange(cols)
            # Use broadcasting to add offsets to start values:
            # start_values[:, None] shape: (rows, 1)
            # row_indices shape: (cols,) -> broadcast to (rows, cols)
            # matrix shape: (rows, cols)
            matrix = start_values[:, jnp.newaxis] + row_indices
            return matrix

        # --- Data Gathering Helpers ---
        @jax.jit
        def create_batch(arr_2d, indices):
            """Extracts rows from arr_2d based on indices."""
            # arr_2d: Data for one env over time (max_replay_size, data_size) NOTE: I think it doesn't have to be 2D
            # indices: Time indices for the sequence (sequence_length,)
            # output: Selected data (sequence_length, data_size)
            return jnp.take(arr_2d, indices, axis=0, mode="wrap") # 'wrap' might be redundant due to max_val calc. (NEED TO BE UNDERSTOOD FURTHER)

        # Vmap create_batch to process all selected environments simultaneously.
        # Takes buffer data sliced along env dim (axis=1) and index matrix sliced along row dim (axis=0).
        create_batch_vmaped = jax.vmap(create_batch, in_axes=(1, 0)) # Map over env dim of data, row dim of matrix

        # --- Generate Sample Indices ---
        # The latest start index must allow the full sequence_length to fit before insert_position.

        # Generate the matrix of absolute time indices to sample.
        # matrix shape: (num_sequences_to_sample, self.sequence_length)
        matrix = create_matrix(
            shape,
            self.sequence_length,
            buffer_state.sample_position,
            buffer_state.insert_position - self.sequence_length,
            sample_key, # Reuse sample_key
        )

        # --- Extract and Unflatten Data ---
        # Select the data for the chosen environments.
        # Use the vmapped function to gather the data slices according to the index matrix.
        # batch shape: (num_sequences_to_sample, self.sequence_length, data_size)
        batch = create_batch_vmaped(buffer_state.data[:, envs_idxs, :], matrix)
        
        # Unflatten the sampled batch back into the original nested structure.
        # Result is typically structured like: (num_sequences_to_sample, self.sequence_length)
        # where each element is a Transition object (or the dummy_data_sample structure).
        transitions = self._unflatten_fn(batch)

        # --- Return ---
        # Return the new buffer state (with updated key) and the sampled transitions.
        return buffer_state.replace(key=key), transitions

    
    # Mark as a static method because it doesn't depend on the buffer instance's state (self). WHAT DOES THIS MEAN?
    @staticmethod
    # NOTE: I NEED TO UNDERSTAND THIS
    # Pre-compile this function using JAX JIT.
    # `buffer_config` is marked as static because its *value* (containing shapes, gamma)
    # determines the computation graph structure, and JAX needs to recompile if it changes.
    # `transition` and `sample_key` change value often, so they are standard JIT arguments.
    @functools.partial(jax.jit, static_argnames=("buffer_config"))
    def flatten_crl_fn(buffer_config, transition, sample_key):
        """Processes a single trajectory sequence for Contrastive RL training.

        This function implements Hindsight Experience Replay (HER) by sampling
        a future state from the trajectory to serve as a goal for earlier states.
        It restructures the transition data for the CRL loss calculation.

        NOTE: This function is designed to be `jax.vmap`ped over a batch of
              trajectory sequences sampled from the buffer. `transition` here
              represents ONE such sequence.

        Args:
            buffer_config: A tuple containing configuration: (gamma, obs_dim,
                           goal_start_idx, goal_end_idx).
            transition: A single trajectory sequence (e.g., a NamedTuple) containing
                        fields like 'observation', 'action', 'extras'. Assumed shape
                        for observation is (sequence_length, original_obs_dim).
            sample_key: A JAX PRNGKey for sampling the future goal state.

        Returns:
            A new Transition NamedTuple, restructured for CRL training:
                - observation: None
                - action: Actions taken (shape: (sequence_length-1, action_dim))
                - extras: Dictionary containing:
                    - 'state': Original states (shape: (sequence_length-1, obs_dim))
                    - 'goal_obs': Relabeled goal observations (shape: (sequence_length-1, obs_dim))
                    - 'goal_action': Actions taken at goal states (shape: (sequence_length-1, action_dim))
                    - 'state_extras': Original extras like 'seed'.
        """
        # Unpack configuration parameters
        gamma, obs_dim, goal_start_idx, goal_end_idx = buffer_config

        # --- Goal Sampling Probability Calculation ---
        # Get the length of the input trajectory sequence
        # transition.observation shape is assumed: (seq_len, original_obs_dim)
        # Because it's vmaped transition.obs.shape is of shape (episode_len, obs_dim)
        seq_len = transition.observation.shape[0]
        # Create indices [0, 1, ..., seq_len-1]
        arrangement = jnp.arange(seq_len)
        # Create a mask indicating future steps: `is_future_mask[i, j] = 1.0` if j > i, else 0.0
        # Shape: (seq_len, seq_len), Upper triangular (excluding diagonal)        
        is_future_mask = jnp.array(arrangement[:, None] < arrangement[None], dtype=jnp.float32)
        # Calculate discounts: `discount[i, j] = gamma**(j - i)`
        # Shape: (seq_len, seq_len)
        discount = gamma ** jnp.array(arrangement[None] - arrangement[:, None], dtype=jnp.float32)        
        # Calculate unnormalized probabilities (logits) for sampling goal `j` from state `i`.
        # Only future states (j > i) have non-zero probability.
        # probs[i, j] = gamma**(j - i) if j > i, else 0.0        
        probs = is_future_mask * discount  
        # the same result can be obtained using probs = is_future_mask * (gamma ** jnp.cumsum(is_future_mask, axis=-1))
        

        # --- Ensure Goals are Sampled Within the Same Original Episode ---
        # Extract the trajectory identifier (seed) for each step in the sequence.
        single_trajectories = jnp.concatenate(
            [transition.extras["state_extras"]["seed"][:, jnp.newaxis].T] * seq_len, axis=0
        )

        # Create a mask `same_traj_mask[i, j] = 1.0` if step `i` and step `j`
        # belong to the same original trajectory/episode, else 0.0.
        # This is important if sequences might cross episode boundaries (e.g., due to AutoReset).
        # compares every pair of steps.
        # Apply the same-trajectory mask to the probabilities.
        # Also add a small epsilon (1e-5) to the diagonal. This prevents log(0) issues
        # during sampling if a state has no valid future states within the same trajectory
        # (e.g., the very last state of an episode within the sequence).
        probs = probs * jnp.equal(single_trajectories, single_trajectories.T) + jnp.eye(seq_len) * 1e-5

        # --- Sample Future Goal Indices ---
        # Sample a goal index `j` for each starting state `i` based on the calculated log probabilities.
        # `jax.random.categorical` expects log-probabilities.
        # `goal_index[i]` stores the time index within the sequence selected as the goal for state `i`.
        # Shape: (seq_len,)
        goal_index = jax.random.categorical(sample_key, jnp.log(probs))

        # --- Extract Relabeled Data Pairs (State, Action, Goal) ---
        # We need pairs (s_i, a_i, g_j) where g_j is the sampled goal for s_i.
        # The last state in the sequence (index seq_len-1) cannot have a goal sampled *for* it
        # from *within* this sequence, so we exclude it when creating the final pairs.

        # Extract the observations corresponding to the *sampled goal indices*.
        # These are the relabeled goal observations 'g'.
        # Shape: (seq_len-1, original_obs_dim)
        goal_obs = jnp.take(transition.observation, goal_index[:-1], axis=0) # the last goal_index cannot be considered as there is no future.  

        # Extract the actions taken *at* the sampled goal states/indices.
        # These might be used by some critic formulations, but not directly by the actor here.
        # Shape: (seq_len-1, action_dim)
        goal_action = jnp.take(transition.action, goal_index[:-1], axis=0)
        # NOTE: When goal_obs is actually used to train the G-Encoder and subsequently the Actor and Critic, it gets sliced again inside the loss functions
        # Inside update_actor_and_alpha / update_critic
        # goal = transitions.extras['goal_obs'][:, args.goal_start_idx : args.goal_end_idx]
        # g_repr = g_encoder.apply(g_encoder_params, goal)

         # Extract the original states 's' for which we just sampled goals.
        # We only take the dimensions relevant as 'state' (excluding potential env goal info).
        # Shape: (seq_len-1, obs_dim)
        state = transition.observation[:-1, : obs_dim]

        # --- Package Relabeled Data ---
        # Create the new 'extras' dictionary containing the processed data needed for CRL training.
        extras = {
            "state_extras": {
                # Keep the original trajectory seed for the states
                "seed": jnp.squeeze(transition.extras["state_extras"]["seed"][:-1]),
            },
            "state": state,     # The original states (s_i)
            "goal_obs": goal_obs,   # The relabeled goal observations (g_j)
            "goal_action": goal_action, # The actions taken at the goal states (a_j)
        }

        # --- Return Restructured Transition ---
        # Use the `_replace` method of the NamedTuple to create a *new* instance.
        return transition._replace(
            # Original full observation is no longer directly needed after processing.
            observation=None,
            # Actions corresponding to the 'state' sequence (a_i).
            # Shape: (seq_len-1, action_dim)
            action=jnp.squeeze(transition.action[:-1]), # Squeeze might be redundant if action_dim > 1
            # The new extras dictionary containing the relabeled (s, g, a_g) data.
            extras=extras,
        )
    

    def size(self, buffer_state):
        """Calculates the current number of valid data points stored in the buffer.

        This represents the number of time steps currently available for sampling,
        across all environments. It's the difference between the insertion point
        and the oldest sample point.

        Args:
            buffer_state: The current state of the replay buffer.

        Returns:
            A scalar JAX array representing the number of valid steps in the buffer.
        """
        # The difference between the next insertion point and the oldest valid data point
        # gives the current number of stored steps.
        return (buffer_state.insert_position - buffer_state.sample_position)